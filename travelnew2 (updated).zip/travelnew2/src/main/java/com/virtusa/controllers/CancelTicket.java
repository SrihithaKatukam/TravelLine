package com.virtusa.controllers;

import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.virtusa.services.TravelLineServiceIface;
import org.apache.log4j.Logger;

@Controller
public class CancelTicket {
	static Logger logger = Logger.getLogger(PaymentDetailController.class);

	@Autowired
	TravelLineServiceIface travelservice;

	@RequestMapping(value = "/cancelTicket", method = RequestMethod.GET)
	public ModelAndView cancelTicket(HttpSession session) {
		try {
			ModelAndView modelAndView = new ModelAndView();
			String s3 = null;
			String s1 = travelservice.returnAmount((String) session.getAttribute("pnrnofordelete"));
			String s2 = travelservice.cancelTicket((String) session.getAttribute("pnrnofordelete"));
			if (s1.equals("returened AMount") && s2.equals("ticket cancelled")) {
				s3 = "Your Ticket Has Been Cancelled Successfully";
				modelAndView.addObject("msg", s3);
				modelAndView.setViewName("PNRcheck");

			} else {
				modelAndView.setViewName("PNRcheck");
			}

			return modelAndView;
		} catch (Exception e) {
			logger.error(e.getMessage());

		}
		return null;

	}
}
