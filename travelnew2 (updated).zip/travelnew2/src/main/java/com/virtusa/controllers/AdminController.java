
package com.virtusa.controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import javax.validation.constraints.Null;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.apache.log4j.Logger;
import com.virtusa.model.Admin;
import com.virtusa.services.TravelLineServiceIface;

@Controller
public class AdminController {

	static Logger logger = Logger.getLogger(PaymentDetailController.class);

	@Autowired
	TravelLineServiceIface travelLineServiceIface;

	@RequestMapping("/tohome")
	public String takemetohome() {
		return "HomePage";
	}

	@RequestMapping("/tolog")
	public String takemetologin() {
		return "LoginAdminjsp";
	}

	@RequestMapping("/tologin")
	public String takemetoadminlogin(Model m) {
		m.addAttribute("login", new Admin());
		return "LoginAdmin";
	}

	@RequestMapping(value = "/AdminLogincheck", method = RequestMethod.POST)
	public ModelAndView login(@Valid @ModelAttribute("login") Admin admin, BindingResult result, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView();
		try {
			int res = travelLineServiceIface.adminLogin(admin.getAdminName(), admin.getPassword());
			if (!result.hasErrors()) {
				if (res == 1) {
					session.setAttribute("name", admin.getAdminName());
					modelAndView.setViewName("AdminAddFile");
				} else {
					modelAndView.addObject("invmsg", "incorrect credentials");
					modelAndView.setViewName("LoginAdmin");
				}

			}
		} catch (Exception e) {

			logger.error(e.getMessage());

		}
		return modelAndView;
	}

	@RequestMapping("/toaddadmin")
	public String takemetoaddadmin(Model m) {
		m.addAttribute("addadmin", new Admin());
		return "AdminAddFile";
	}

	@RequestMapping(value = "/AddAdmin", method = RequestMethod.POST)
	public ModelAndView addAdmin(@RequestParam("adminName") String name, @RequestParam("password") String pwd,
			@RequestParam("conpassword") String cfp, HttpSession session) {

		ModelAndView modelAndView = new ModelAndView();
		if (!name.isEmpty() && !pwd.isEmpty() && !cfp.isEmpty()) 
		{
			if (pwd.equals(cfp)) {

				Admin ad = new Admin();
				ad.setAdminName(name);
				ad.setPassword(pwd);

				String res = travelLineServiceIface.addAdmin(ad);
				if (res != null) {
					String message = "Added Successfully";
					modelAndView.addObject("message", message);
					modelAndView.setViewName("AdminAddFile");

				} else {
					String message = "Invalid credentials";
					modelAndView.addObject("message", message);
					modelAndView.setViewName("AdminAddFile");

				}

			} else {
				String message = "Invalid credentials";
				modelAndView.addObject("message", message);
				modelAndView.setViewName("AdminAddFile");

			}
		} else {
			String message = "Name And Password Fields Cannot be null";
			modelAndView.addObject("message", message);
			modelAndView.setViewName("AdminAddFile");
		}

		return modelAndView;
	}

	@RequestMapping("/toLogOut")
	public String takemetologout(HttpSession session, Model m) {
		session.removeAttribute("name");
		session.invalidate();
		m.addAttribute("login", new Admin());
		return "LoginAdmin";

	}

	@RequestMapping("/toHomePage")
	public String takemetoHomePagen() {
		return "HomePage";
	}

}
