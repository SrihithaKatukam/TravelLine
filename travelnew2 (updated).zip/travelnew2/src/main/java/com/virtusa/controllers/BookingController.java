package com.virtusa.controllers;

import java.util.List;
import org.apache.log4j.Logger;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.virtusa.model.Service1;
import com.virtusa.services.TravelLineServiceIface;

@Controller
public class BookingController {

	static Logger logger = Logger.getLogger(PaymentDetailController.class);
	@Autowired
	TravelLineServiceIface service;

	@RequestMapping(value = "/SelectServ1", method = RequestMethod.POST)
	public ModelAndView delectservice(@RequestParam("from") String from, @RequestParam("to") String to,
			@RequestParam("no_passenger") String passenger, @RequestParam("doj") String doj, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView();
		try {
			String s = "yes";
			String s1 = null;
			List<Service1> list = service.findBuses(from, to, s);
			int x = list.size();
			if (!list.isEmpty()) {
				String sno = list.get(0).getServiceId();
				String depttime1 = list.get(0).getDepartureTime();
				String jourtime1 = list.get(0).getJourneyTime();
				session.setAttribute("sno", sno);
				modelAndView.addObject("list", list);
				modelAndView.addObject("length", x);
				modelAndView.addObject("from1", from);
				modelAndView.addObject("to1", to);
				modelAndView.addObject("date1", doj);
				session.setAttribute("from", from);
				session.setAttribute("to", to);
				session.setAttribute("noofpsg", passenger);
				session.setAttribute("date", doj);
				session.setAttribute("jtime", jourtime1);
				session.setAttribute("depttime", depttime1);
				modelAndView.setViewName("SelectService");
			} else {
				s1 = "!No Buses Available";
				modelAndView.addObject("from1", from);
				modelAndView.addObject("to1", to);
				modelAndView.addObject("date1", doj);
				modelAndView.addObject("length", x);
				modelAndView.addObject("msg1", s1);
				modelAndView.setViewName("SelectService");
			}
		} catch (Exception e) {
			logger.error(e.getMessage());

		}
		return modelAndView;

	}

	@RequestMapping(value = "/SeatArrange", method = RequestMethod.POST)
	public ModelAndView seatArrange(@RequestParam("selectedRadio") String radio, HttpSession session) {
		try {
			ModelAndView modelAndView = new ModelAndView();
			int bs1[] = service.getAllSeat((String) session.getAttribute("sno"), (String) session.getAttribute("sno"));
			modelAndView.addObject("array", bs1);
			modelAndView.addObject("serviceid", radio);
			modelAndView.addObject(session.getAttribute("from"));
			modelAndView.addObject(session.getAttribute("to"));
			modelAndView.addObject(session.getAttribute("noofpsg"));
			modelAndView.addObject(session.getAttribute("date"));
			session.setAttribute("serviceid", radio);
			modelAndView.setViewName("SeatArrangement");
			return modelAndView;
		} catch (NumberFormatException e) {
			logger.error(e.getMessage());

		}
		return null;
	}

	@RequestMapping(value = "/PaymentCard", method = RequestMethod.POST)
	public ModelAndView paymentcard(@RequestParam("r") String r[], HttpSession session) {
		try {
			ModelAndView modelAndView = new ModelAndView();
			String[] seats = r;
			int x = seats.length;
			String srno = (String.valueOf(session.getAttribute("serviceid")));
			String fr = (String.valueOf(session.getAttribute("from")));
			String to = (String.valueOf(session.getAttribute("to")));
			String dt = (String.valueOf(session.getAttribute("date")));
			modelAndView.addObject("array1", seats);
			modelAndView.addObject("serviceno", srno);
			modelAndView.addObject("from", fr);
			modelAndView.addObject("to", to);
			modelAndView.addObject("date", dt);
			modelAndView.addObject("size", x);
			modelAndView.setViewName("Passenger");
			return modelAndView;
		} catch (Exception e) {
			logger.error(e.getMessage());

		}
		return null;

	}

	@RequestMapping("/toPassenger")
	public String taketopassenger() {
		return "Passenger";
	}

	
	@RequestMapping("/toGallery")
	public String toGallery() {
		return "Gallery";
	}

	@RequestMapping("/toTermsandCond")
	public String toTermsandCond() {
		return "TermsandConditions";
	}
}
