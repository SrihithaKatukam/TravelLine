package com.virtusa.controllers;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.virtusa.model.BookingMap;
import com.virtusa.model.Card;
import com.virtusa.model.Passenger;
import com.virtusa.services.TravelLineServiceIface;
import org.apache.log4j.Logger;

@Controller
public class PaymentDetailController {

	static Logger logger = Logger.getLogger(PaymentDetailController.class);
	@Autowired
	TravelLineServiceIface service;

	@RequestMapping(value = "/PayCardInput", method = RequestMethod.POST)
	public ModelAndView seatArrange(@RequestParam("Pname") String pname[], @RequestParam("age") String age[],
			@RequestParam("seatno") String seatno[], @RequestParam("ProofId") String proofid,
			@RequestParam("Email") String email, @RequestParam("Phone") Long phone,
			@RequestParam("Proofno") String proono, HttpSession session) {
		try {
			ModelAndView modelAndView = new ModelAndView();
			modelAndView.addObject("pname", pname);
			modelAndView.addObject("age", age);
			modelAndView.addObject("seatno", seatno);
			modelAndView.addObject("proofid", proofid);
			Passenger md = new Passenger();
			String passengerid = service.passengerIdGenrate();
			md.setEmail(email);
			md.setMobNo(phone);
			md.setName(pname[0]);
			md.setProofName(proofid);
			md.setPassengerId(passengerid);
			md.setProofNo(proono);
			session.setAttribute("MasterDetail", md);
			session.setAttribute("pname", pname);
			session.setAttribute("pAge", age);
			session.setAttribute("Seatno", seatno);
			session.setAttribute("proofno", proono);
			session.setAttribute("proofid", proofid);
			int fare = service.getFare(session.getAttribute("sno").toString());
			modelAndView.addObject("totalfare", fare);
			session.setAttribute("totalfare", fare);

			if (fare > 0) {
				modelAndView.setViewName("PaymentCardInput");
			} else {
				modelAndView.setViewName("Passenger");
			}

			return modelAndView;
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return null;

	}

	@RequestMapping(value = "/PaymentCardInsert", method = RequestMethod.POST)
	public ModelAndView seatArrange(@RequestParam("cardNo") String cardno, @RequestParam("cardHn") String cardhn,
			@RequestParam("cvvNo") int cvvno, @RequestParam("expDate") String expdate, HttpSession session) {
		try {
			ModelAndView mv = new ModelAndView();
			if (cardno != null && cardhn != null && cvvno != 0 && expdate != null) {
				Card c = new Card();
				c.setCardNo(cardno);
				c.setCardHn(cardhn);
				c.setCvvNo(cvvno);
				c.setExpDate(expdate);
				String pnrno = service.pnrGenrate();
				String psngId = service.passengerIdGenrate();
				String bookingid = service.genrateBookingId();
				@SuppressWarnings("deprecation")
				java.util.Date ud = new Date(session.getAttribute("date").toString());
				session.setAttribute("pnrno", pnrno);
				String pname[] = (String[]) session.getAttribute("pname");
				String pAge[] = (String[]) session.getAttribute("pAge");
				String seatNo[] = (String[]) session.getAttribute("Seatno");
				int size = pname.length;
				Passenger md = (Passenger) session.getAttribute("MasterDetail");
				String proof = String.valueOf(session.getAttribute("proofno"));
				String proofid = String.valueOf(session.getAttribute("proofid"));
				String servicenumber = String.valueOf(session.getAttribute("serviceid"));
				String jtime = String.valueOf(session.getAttribute("jtime"));
				String deptime = String.valueOf(session.getAttribute("depttime"));
				Passenger s1 = service.ticketDetail(pnrno, pname, pAge, seatNo, md, psngId, proof, proofid);
				List<BookingMap> bookingMaps = new ArrayList<BookingMap>();
				for (int i = 0; i < pname.length; i++) {
					BookingMap bookingMap = new BookingMap();
					bookingMap.setPname(pname[i]);
					bookingMap.setSeatNo(Integer.parseInt(seatNo[i]));
					bookingMap.setAge(Integer.parseInt(pAge[i]));
					bookingMap.setBookingId(bookingid);
					bookingMaps.add(bookingMap);
				}
				int fare = Integer.parseInt(String.valueOf(session.getAttribute("totalfare")));
				String s2 = service.insertBooking(s1, pnrno, ud, (String) session.getAttribute("sno"), psngId,
						Integer.parseInt(session.getAttribute("noofpsg").toString()), bookingid, c, fare, bookingMaps);
				mv.addObject("servicenumber", servicenumber);
				mv.addObject("pnrno", pnrno);
				mv.addObject("jdate", ud);
				mv.addObject("totalfare", fare);
				mv.addObject("size", size);
				mv.addObject("totalfare", fare);
				mv.addObject("pname", pname);
				mv.addObject("page", pAge);
				mv.addObject("seatnumber", seatNo);
				mv.addObject("jtime", jtime);
				mv.addObject("depttime", deptime);

				if (s2.equals("booking inserted")) {
					mv.setViewName("ShowDetail");
				}
			}
			return mv;
		} catch (NumberFormatException e) {
			logger.error(e.getMessage());
		}
		return null;
	}

	@RequestMapping("/toPayCardInput")
	public String paycardinput() {
		return "redirect:/PayCardInput";
	}
}
