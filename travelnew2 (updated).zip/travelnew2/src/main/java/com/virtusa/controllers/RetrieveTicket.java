package com.virtusa.controllers;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.apache.log4j.Logger;
import com.virtusa.model.RetrievalDao;
import com.virtusa.model.Service1;
import com.virtusa.services.TravelLineServiceIface;

@Controller
public class RetrieveTicket {

	static Logger logger = Logger.getLogger(PaymentDetailController.class);

	@Autowired
	TravelLineServiceIface travelservice;

	@RequestMapping(value = "/retrivalTicket", method = RequestMethod.POST)
	public ModelAndView cancelTicket(@RequestParam("pnrno") String pnrno, @RequestParam("IdNo") String idno,
			HttpSession session) {
		try {
			String s1 = null;

			ModelAndView modelAndView = new ModelAndView();
			if (pnrno != null && idno != null) {
				if (travelservice.checkPNR(pnrno) && travelservice.checkProof(idno)) {
					RetrievalDao rdao = travelservice.pnrDetails(pnrno);
					session.setAttribute("pnrnofordelete", pnrno);
					Service1 sobj = rdao.getSer();
					String servno = sobj.getServiceNo();
					List<String> allpassNames = rdao.getPname();
					List<Integer> allpassSeats = rdao.getSeatNo();
					Date date = rdao.getJourneydate();
					modelAndView.addObject("passname", allpassNames);
					modelAndView.addObject("date", date);
					modelAndView.addObject("pnrno", pnrno);
					modelAndView.addObject("passseats", allpassSeats);
					modelAndView.addObject("serviceobj", sobj);
					modelAndView.addObject("rdao", rdao);
					modelAndView.addObject("serviceno", servno);
					modelAndView.setViewName("retrivalOpen");

				} else {
					s1 = "Not correct pnr or id proof";
					modelAndView.addObject("msg", s1);
					modelAndView.setViewName("PNRcheck");
				}
			}
			return modelAndView;
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return null;

	}

	@RequestMapping(value = "toPnrCheck", method = RequestMethod.GET)
	public String topnrcheck() {
		return "PNRcheck";
	}
}
