package com.virtusa.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
//import org.apache.log4j.Logger;

@Entity
@Table(name = "feedback_tab2")
public class Feedback {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int feedbackId;

	@Column(name = "cust_name")
	private String customerName;

	@Column(name = "mail_id")
	private String mailId;
	@Column(name = "comments")
	private String comments;

	//static Logger logger = Logger.getLogger(Feedback.class);

	public int getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	/*
	 * public static Logger getLogger() { return logger; }
	 * 
	 * public static void setLogger(Logger logger) { Feedback.logger = logger; }
	 */

}
