package com.virtusa.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "bookmap_table2")
public class BookingMap {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int bookid;
	
	@Column
	private String bookingId;

	@Column
	private int seatNo;
	@Column
	private String pname;
	@Column
	private int age;

	@ManyToOne
	@JoinColumn(name = "bookingId", referencedColumnName = "bookingId", insertable = false, updatable = false)
	private Booking book;

	public Booking getBook() {
		return book;
	}

	public void setBook(Booking book) {
		this.book = book;
	}

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public int getSeatNo() {
		return seatNo;
	}

	public void setSeatNo(int seatNo) {
		this.seatNo = seatNo;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

}
