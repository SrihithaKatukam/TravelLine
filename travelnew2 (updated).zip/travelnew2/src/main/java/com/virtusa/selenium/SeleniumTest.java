package com.virtusa.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SeleniumTest {
	WebDriver driver = new ChromeDriver();

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "F:\\lib\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://localhost:8080/travelnew2/tologin");
		// login
		driver.findElement(By.xpath("//*[@id=\"adminName\"]")).sendKeys("krishnakant");
		driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("pathak");
		driver.findElement(By.xpath("/html/body/div[2]/form/center/div/table/tbody/tr[4]/td/input[1]")).click();
		
		  //Add Admin
		
		/*
		 * driver.findElement(By.xpath(
		 * "/html/body/div[2]/form/center/div/table/tbody/tr[1]/td/input")).sendKeys(
		 * "rishi"); driver.findElement(By.xpath(
		 * "/html/body/div[2]/form/center/div/table/tbody/tr[2]/td/input")).sendKeys(
		 * "pathak"); driver.findElement(By.xpath(
		 * "/html/body/div[2]/form/center/div/table/tbody/tr[3]/td/input")).sendKeys(
		 * "pathak"); driver.findElement(By.xpath(
		 * "/html/body/div[2]/form/center/div/table/tbody/tr[4]/td/input[1]")).click();
		 */
		  
		
		  //Add Service
		  driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul[1]/li[1]/a")).click
		  (); 
		  driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul[1]/li[1]/ul/li[1]/a/strong")).click(); 
		  new Select(driver.findElement(By.xpath("//*[@id=\"srFrom\"]"))).selectByIndex(2);
		  new
		  Select(driver.findElement(By.xpath("//*[@id=\"srTo\"]"))).selectByIndex(4);
		  new
		  Select(driver.findElement(By.xpath("//*[@id=\"typeId\"]"))).selectByIndex(2);
		  driver.findElement(By.xpath("//*[@id=\"fare\"]")).sendKeys("2563");
		  driver.findElement(By.xpath("//*[@id=\"disKMS\"]")).sendKeys("3200"); new
		  Select(driver.findElement(By.xpath("//*[@id=\"capacity\"]"))).selectByIndex(3); 
		  driver.findElement(By.xpath("//*[@id=\"journeyTime\"]")).sendKeys("21");
		  driver.findElement(By.xpath("//*[@id=\"departureTime\"]")).sendKeys("02:30AM"
		  );
		  driver.findElement(By.xpath("//*[@id=\"serviceNo\"]")).sendKeys("PLMN4066BD"); 
		  driver.findElement(By.
		  xpath(" /html/body/center/form/table/tbody/tr[10]/td/center/input[1]")).click
		  ();
		 
		 
		  //View Schedules
		  driver.findElement(By.xpath(" /html/body/nav/div/div[2]/ul[1]/li[2]/a")).click();
		  driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul[1]/li[2]/ul/li[2]/a/strong")).click();
		  
		  //view feedback
		  driver.findElement(By.xpath(" /html/body/nav/div/div[2]/ul[1]/li[2]/a")).click();
		  driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul[1]/li[2]/ul/li[1]/a/strong")).click();
		 
		  //view contacts
		  
		  driver.findElement(By.xpath(" /html/body/nav/div/div[2]/ul[1]/li[2]/a")).click();
		  driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul[1]/li[2]/ul/li[3]/a/strong")).click();

		 
		  //Log Out
		  
		  driver.findElement(By.xpath(" /html/body/nav/div/div[2]/ul[2]/li/a")).click();
		  driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul[2]/li[1]/ul/li/a")).click();
		  
		  //Home 
		 
		  driver.findElement(By.xpath(" /html/body/button")).click();
		  
		  //Booking User
		  driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul[1]/li[3]/ul/li[1]/a/strong")).click();
		  new Select(driver.findElement(By.xpath("/html/body/div[1]/center/div/form/ul/li[1]/input"))).selectByIndex(2);
		  new Select(driver.findElement(By.xpath("  /html/body/div[1]/center/div/form/ul/li[2]/input"))).selectByIndex(6);
		  driver.findElement(By.xpath("/html/body/div[1]/center/div/form/ul/li[3]/input")).sendKeys("1");
		  driver.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[4]/td[4]/a"));
		  
		  
	}

}
