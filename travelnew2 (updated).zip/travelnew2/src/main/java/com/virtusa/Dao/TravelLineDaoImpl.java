
package com.virtusa.Dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.virtusa.model.Admin;
import com.virtusa.model.Booking;
import com.virtusa.model.BookingMap;
import com.virtusa.model.Card;
import com.virtusa.model.ContactUs;
import com.virtusa.model.Feedback;
import com.virtusa.model.Identity;
import com.virtusa.model.Passenger;
import com.virtusa.model.Payment;
import com.virtusa.model.RetrievalDao;
import com.virtusa.model.Service1;
import org.apache.log4j.Logger;

@Repository
public class TravelLineDaoImpl implements TravelLineDaoIface {
	static Logger logger = Logger.getLogger(TravelLineDaoImpl.class);

	@Autowired
	SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public int adminLogin(String name, String pass) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from Admin where adminName=:name AND password=:pass");
			query.setParameter("name", name);
			query.setParameter("pass", pass);
			List<Admin> list = query.list();
			if (list.size() > 0) {
				return 1;
			} else {
				return 0;
			}
		} catch (HibernateException e) {
			logger.error(e.getMessage());
		}
		return 0;
	}

	@Transactional
	public String addAdmin(Admin a) {

		try {
			String s = null;

			Session session = sessionFactory.getCurrentSession();

			int n = (Integer) session.save(a);

			if (n > 0) {
				s = "data inserted successfully";
			}
			return s;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return null;

	}

	@Transactional
	public int[] getAllSeat(String serviceid, String sno) {

		try {
			Session session = sessionFactory.getCurrentSession();
			Query query1 = session.createQuery("select capacity from Service1 where serviceId=:id");
			query1.setParameter("id", serviceid);
			List<Integer> lst = query1.list();
			int cap = lst.get(0);
			int bsl[] = new int[cap + 1];
			int x = 0;
			SQLQuery query = session.createSQLQuery(
					"select bm.seatNo from booking_table2 b inner join bookmap_table2 bm on bm.bookingId=b.bookingId where b.serviceId=:id");
			query.setParameter("id", sno);
			List<BigDecimal> l = query.list();

			for (BigDecimal b : l) {
				bsl[x++] = b.intValue();
			}

			return bsl;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return new int[0];

	}

	@Transactional
	public int getFare(String servid) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Query query1 = session.createQuery("select fare from Service1 where serviceId=:id");
			query1.setParameter("id", servid);
			List<Integer> list = query1.list();
			int x = list.get(0);
			return x;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return 0;
	}

	public int insertCard(Card c) {
		try {
			Session session = sessionFactory.getCurrentSession();
			int x = (Integer) session.save(c);
			if (x > 0)
				return x;
			else
				return 0;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return 0;
	}

	public String paymentIdGenrate() {
		try {
			String cmd = "select " + "	Case when max(PAYMENTID) is null THEN 'PAY001' "
					+ "		 when max(PAYMENTID) is not null THEN  "
					+ "			Case When To_Number(substr(max(PAYMENTID),4))+1<10 THEN "
					+ "				concat('PAY00',TO_Char(to_number(substr(max(PAYMENTID),4))+1)) "
					+ "				WHEN To_Number(substr(max(PAYMENTID),4))+1>=10 AND To_Number(substr(max(PAYMENTID),4))+1<100 THEN "
					+ "				concat('PAY00',TO_Char(to_number(substr(max(PAYMENTID),4))+1)) "
					+ "				WHEN To_Number(substr(max(PAYMENTID),4))+1>100 THEN "
					+ "				concat('PAY',TO_Char(to_number(substr(max(PAYMENTID),4))+1)) "
					+ "	end end payid from payment_table2";
			Session session = this.getSessionFactory().getCurrentSession();
			SQLQuery query = session.createSQLQuery(cmd);
			List<String> lst = query.list();
			String s = lst.get(0);
			if (s != null)
				return s;
			else
				return null;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return null;
	}

	public String pnrGenrate() {
		try {
			String cmd = "select Case when max(pnrno) is null THEN 'PNR001' "
					+ "		 when max(pnrno) is not null THEN  "
					+ "			Case When To_Number(substr(max(pnrno),4))+1<10 THEN "
					+ "				concat('PNR00',TO_Char(to_number(substr(max(pnrno),4))+1)) "
					+ "				WHEN To_Number(substr(max(pnrno),4))+1>=10 AND To_Number(substr(max(pnrno),4))+1<100 THEN "
					+ "				concat('PNR00',TO_Char(to_number(substr(max(pnrno),4))+1)) "
					+ "				WHEN To_Number(substr(max(pnrno),4))+1>100 THEN "
					+ "				concat('s',TO_Char(to_number(substr(max(pnrno),4))+1)) "
					+ "	end end pnrno from booking_table2";
			Session session = this.getSessionFactory().getCurrentSession();
			SQLQuery query = session.createSQLQuery(cmd);
			List<String> lst = query.list();
			String s = lst.get(0);
			if (s != null)
				return s;
			else
				return null;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return null;
	}

	public String passengerIdGenrate() {
		try {
			String cmd = "select Case when max(passengerid) is null THEN 'P001'"
					+ "		 when max(passengerid) is not null THEN "
					+ "			Case When To_Number(substr(max(passengerid),2))+1<10 THEN"
					+ "				concat('P00',TO_Char(to_number(substr(max(passengerid),2))+1))"
					+ "				WHEN To_Number(substr(max(passengerid),2))+1>=10 AND To_Number(substr(max(passengerid),2))+1<100 THEN"
					+ "				concat('P0',TO_Char(to_number(substr(max(passengerid),2))+1))"
					+ "				WHEN To_Number(substr(max(passengerid),2))+1>100 THEN"
					+ "				concat('P',TO_Char(to_number(substr(max(passengerid),2))+1))"
					+ "	end end passengerid from passenger_table2";
			Session session = sessionFactory.getCurrentSession();
			SQLQuery query = session.createSQLQuery(cmd);
			List<String> lst = query.list();
			String s = lst.get(0);
			if (s != null)
				return s;
			else
				return null;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return null;
	}

	public String genrateServiceId() {
		try {
			String cmd = "select Case when max(serviceId) is null THEN 's001'"
					+ "		 when max(serviceId) is not null THEN "
					+ "			Case When To_Number(substr(max(serviceId),2))+1<10 THEN"
					+ "				concat('s00',TO_Char(to_number(substr(max(serviceId),2))+1))"
					+ "				WHEN To_Number(substr(max(serviceId),2))+1>=10 AND To_Number(substr(max(serviceId),2))+1<100 THEN"
					+ "				concat('s0',TO_Char(to_number(substr(max(serviceId),2))+1))"
					+ "				WHEN To_Number(substr(max(serviceId),2))+1>100 THEN"
					+ "				concat('s',TO_Char(to_number(substr(max(serviceId),2))+1))"
					+ "	end end serviceId from service_table2";
			Session session = this.getSessionFactory().getCurrentSession();
			SQLQuery query = session.createSQLQuery(cmd);
			List<String> lst = query.list();
			String s = lst.get(0);
			if (s != null)
				return s;
			else
				return null;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return null;
	}

	public String genrateBookingId() {
		try {
			String cmd = "select Case when max(bookingid) is null THEN 'BN01'"
					+ "		 when max(bookingid) is not null THEN "
					+ "			Case When To_Number(substr(max(bookingid),3))+1<10 THEN"
					+ "				concat('BN0',TO_Char(to_number(substr(max(bookingid),3))+1))"
					+ "				ELSE" + "				concat('BN',TO_Char(to_number(substr(max(bookingid),3))+1))"
					+ "	end end bookingid from booking_table2";
			Session session = this.getSessionFactory().getCurrentSession();
			SQLQuery query = session.createSQLQuery(cmd);
			List<String> lst = query.list();
			String s = lst.get(0);
			if (s != null)
				return s;
			else
				return null;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return null;

	}

	@Transactional
	public String insertBooking(Passenger passenger, String pnrno, Date journeyDate, String serviceId,
			String passengerId, int noOfSeats, String bookingid, Card card, int fare, List<BookingMap> bookingMap) {

      		Session session = sessionFactory.getCurrentSession();
			Transaction transaction = session.beginTransaction();
			session.save(card);
			transaction.commit();
			transaction.begin();
			Booking booking = new Booking();
			Date date = new Date();
			booking.setBookingDate(date);
			booking.setJourneyDate(journeyDate);
			booking.setBookingId(bookingid);
			booking.setPnrNo(pnrno);
			booking.setNoOfSeats(noOfSeats);
			booking.setPassengerId(passengerId);
			booking.setServiceId(serviceId);
			booking.setBookmap(bookingMap);
			session.save(booking);
			transaction.commit();
			transaction.begin();
			Payment p = new Payment();
			p.setPaymentId(this.paymentIdGenrate());
			p.setBookingId(bookingid);
			p.setCreditCardNo(card.getCardNo());
			p.setTotalFare(fare);
			p.setBookingId(bookingid);
			session.save(p);
			transaction.commit();
		

		return "booking inserted";
	}

	@Transactional
	public Passenger ticketDetail(String pnrNo, String[] pname, String[] page, String[] seatNo, Passenger md,
			String psngId, String proof, String proofname) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Transaction transaction = session.beginTransaction();
			Identity identity = new Identity();
			identity.setProofNo(proof);
			identity.setProofName(proofname);
			session.save(identity);
			transaction.commit();
			transaction.begin();
			Passenger stm = new Passenger();
			stm.setEmail(md.getEmail());
			stm.setMobNo(md.getMobNo());
			stm.setProofName(md.getProofName());
			stm.setProofNo(md.getProofNo());
			stm.setName(md.getName());
			stm.setPassengerId(psngId);
			session.save(stm);
			transaction.commit();
			return stm;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return null;
	}

	@Transactional
	public String cancelTicket(String pnrNo) {

		Session session = sessionFactory.getCurrentSession();
		String cmd = "select bookingid,passengerid from booking_table2 where pnrNo=:pnrnum";
		String findcmd = "select proofNo from passenger_table2 where passengerid=:pnr";
		String dcmd1 = "delete from passenger_table2 where passengerId=:psgid";
		String dcmd2 = "delete from bookmap_table2 where bookingId=:bookid";
		String dcmd3 = "delete from payment_table2 where bookingId=:bookid2";
		String dcmd4 = "delete from booking_table2 where bookingId=:bookid3";
		String dcmd5 = "delete from identity_table2 where proofNo=:proofno";
		String bookingid = null;
		String passengerid = null;
		String idno = null;
		SQLQuery sqlQuery = sessionFactory.getCurrentSession().createSQLQuery(cmd);
		sqlQuery.setParameter("pnrnum", pnrNo);
		List<Object[]> obj = sqlQuery.list();
		for (Object[] objects : obj) {
			bookingid = (objects[0].toString());
			passengerid = objects[1].toString();
		}
		SQLQuery sqlQuery7 = session.createSQLQuery(dcmd5);
		sqlQuery7.setParameter("proofno", idno);
		sqlQuery7.executeUpdate();

		SQLQuery sqlQuery4 = session.createSQLQuery(dcmd2);
		sqlQuery4.setParameter("bookid", bookingid);
		sqlQuery4.executeUpdate();
		SQLQuery sqlQuery6 = session.createSQLQuery(dcmd4);
		sqlQuery6.setParameter("bookid3", bookingid);
		sqlQuery6.executeUpdate();

		SQLQuery sqlQuery2 = session.createSQLQuery(findcmd);
		sqlQuery2.setParameter("pnr", passengerid);
		List<String> list = sqlQuery2.list();
		idno = list.get(0);
		SQLQuery sqlQuery3 = session.createSQLQuery(dcmd1);
		sqlQuery3.setParameter("psgid", passengerid);
		sqlQuery3.executeUpdate();

		SQLQuery sqlQuery5 = session.createSQLQuery(dcmd3);
		sqlQuery5.setParameter("bookid2", bookingid);
		sqlQuery5.executeUpdate();

		return "ticket cancelled";
	}

	@Transactional
	public RetrievalDao pnrDetails(String pnrNo) {
		String cmd3 = "from Booking where pnrNo=:pnrno";
		String cmd4 = "select * from service_table2 where serviceId=:service";
		String cmd5 = "select journeyDate from booking_table2 where serviceId=:id";
		String cmd6 = "select * from bookmap_table2 where bookingId=:bookid";
		String cmd7 = "select * from passenger_table2 where passengerId=:passid";
		RetrievalDao rdao = new RetrievalDao();
		Query query = this.getSessionFactory().getCurrentSession().createQuery(cmd3);
		query.setParameter("pnrno", pnrNo);
		Booking booking = (Booking) query.list().get(0);
		String serviceid = booking.getServiceId().toString();
		String bookid = booking.getBookingId().toString();
		String passengerid = booking.getPassengerId().toString();
		Service1 ser = (Service1) sessionFactory.getCurrentSession().get(Service1.class, serviceid);
//		List<Object[]> list1 = query2.list();
//		Iterator it = list1.iterator();
//		while (it.hasNext()) {
//			Service1 service = (Service1) it.next();
//			ser.setSrFrom(service.getSrFrom());
//			ser.setSrTo(service.getSrTo());
//			ser.setDepartureTime(service.getDepartureTime());
//			ser.setServiceNo(service.getServiceNo());
//			ser.setFare(service.getFare());
//			ser.setJourneyTime(service.getJourneyTime());
//		}
		rdao.setSer(ser);
		SQLQuery query3 = sessionFactory.getCurrentSession().createSQLQuery(cmd5);
		query3.setParameter("id", serviceid);
		List<Date> list2 = query3.list();
		Date d = list2.get(0);
		rdao.setJourneydate((java.util.Date) d);
		SQLQuery query4 = sessionFactory.getCurrentSession().createSQLQuery(cmd6);
		query4.setParameter("bookid", bookid);

		List<String> pnames = new ArrayList<String>();
		List<Integer> seats = new ArrayList<Integer>();
		List<Object[]> bookingMapObjects = query4.list();
		List<BookingMap> bookingMaps = new ArrayList<BookingMap>();
		for (Object[] bookingMap : bookingMapObjects) {
			pnames.add(bookingMap[0].toString());
			seats.add(Integer.parseInt(bookingMap[0].toString()));
		}
		rdao.setPname(pnames);
		rdao.setSeatNo(seats);
		SQLQuery query5 = sessionFactory.getCurrentSession().createSQLQuery(cmd7);
		query5.setParameter("passid", passengerid);
		List<Object[]> obj = query5.list();
		for (Object[] object : obj) {
			rdao.setMasterName(object[3].toString());
			rdao.setMasterProofType(object[5].toString());
		}

		return rdao;

	}

	@Transactional
	public String returnAmount(String pnrNo) {
		Session session = sessionFactory.getCurrentSession();
		String bookingid = null;
		String cardno = null;
		int balance = 0;
		String cmd1 = "select bookingId from booking_table2 where pnrNo=:pnr";
		String cmd2 = "select creditCardNo from payment_table2 where bookingId=:bookingid";
		String cmd21 = "select totalFare from payment_table2 where bookingId=:bookingid";
		String cmd3 = "update card_table2 set availablebalance=:balance where cardno=:cardno";
		String cmd4 = "delete from payment_table2 where bookingId=:bookid";
		SQLQuery sqlQuery1 = session.createSQLQuery(cmd1);
		sqlQuery1.setParameter("pnr", pnrNo);
		List<String> list = sqlQuery1.list();
		bookingid = list.get(0);
		SQLQuery sqlQuery2 = session.createSQLQuery(cmd2);
		sqlQuery2.setParameter("bookingid", bookingid);
		List<String> list2 = sqlQuery2.list();
		cardno = list2.get(0);
		SQLQuery sqlQuery21 = session.createSQLQuery(cmd21);
		sqlQuery21.setParameter("bookingid", bookingid);
		List<BigDecimal> list21 = sqlQuery21.list();
		balance = list21.get(0).intValue();
		SQLQuery sqlQuery3 = session.createSQLQuery(cmd3);
		sqlQuery3.setInteger("balance", balance);
		sqlQuery3.setParameter("cardno", cardno);
		sqlQuery3.executeUpdate();
		SQLQuery sqlQuery4 = session.createSQLQuery(cmd4);
		sqlQuery4.setParameter("bookid", bookingid);
		sqlQuery4.executeUpdate();
		return "returened AMount";
	}

	@Transactional
	public boolean checkProof(String idtype) {
		boolean flag;
		String cmd = "select proofNo from identity_table2 where proofNo=:prroof";
		SQLQuery sqlQuery = sessionFactory.getCurrentSession().createSQLQuery(cmd);
		sqlQuery.setParameter("prroof", idtype);
		List<String> list = sqlQuery.list();
		if (list.isEmpty()) {
			flag = false;
		} else {
			flag = true;
		}
		System.out.println("proof chk " + flag);
		return flag;
	}

	@Transactional
	public List<Service1> displaySchedules() {
		try {
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from Service1 order by serviceId");
			List<Service1> list = query.list();
			return list;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return Collections.emptyList();
	}

	@Transactional
	public List<Service1> modifyService(String serviceid) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from Service1 where serviceId=:id");
			query.setString("id", serviceid);
			List<Service1> list = query.list();
			return list;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return Collections.emptyList();
	}

	@Transactional
	public boolean checkPNR(String pnrno) {
		boolean flag;
		String cmd = "select pnrNo from booking_table2 where pnrNo=:pnrnum";
		SQLQuery sqlQuery = sessionFactory.getCurrentSession().createSQLQuery(cmd);
		sqlQuery.setParameter("pnrnum", pnrno);
		List<String> bookings = sqlQuery.list();
		if (bookings.isEmpty())
			flag = false;
		else
			flag = true;

		System.out.println("pnr chk " + flag);
		return flag;
	}

	@Transactional
	public String sendMessage(ContactUs cus) {
		try {
			Session session = sessionFactory.getCurrentSession();
			int x = (Integer) session.save(cus);
			if (x > 0)
				return "Your Message Sent Succesfully!";
			else
				return null;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return null;
	}

	@Transactional
	public List<ContactUs> getAllMsg() {
		try {
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from ContactUs ");
			List<ContactUs> list = query.list();
			return list;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return Collections.emptyList();
	}

	@Transactional
	public int addFeedback(Feedback fb) {
		try {
			int x = 0;
			Session s = sessionFactory.getCurrentSession();
			s.save(fb);
			x = 1;
			return x;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return 0;
	}

	@Transactional
	public List<Feedback> displayFeedback() {
		try {
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from Feedback order by feedbackId");
			List<Feedback> list = query.list();
			return list;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return Collections.emptyList();
	}

	@Transactional
	public int addService(Service1 s) {

		Session session = sessionFactory.getCurrentSession();
		int n = 0;
		s.setServiceId(this.genrateServiceId());
		s.setActive("yes");
		session.save(s);
		n = 1;
		if (n > 0)
			return n;
		else
			return 0;
	}

	@Transactional
	public int updateModifyService(Service1 s) {
		try {
			int x = 0;
			Session session = sessionFactory.getCurrentSession();
			session.update(s);
			x = 1;
			return x;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return 0;

	}

	@Transactional
	public List<Service1> findBuses(String from, String to, String active) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from Service1 where srFrom=:from1 AND srto=:to AND active=:active");
			query.setParameter("from1", from);
			query.setParameter("to", to);
			query.setParameter("active", active);
			List<Service1> list = query.list();
			return list;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return Collections.emptyList();
	}

	@Transactional
	public int getSeatCapacity(String serviceid) {
		try {
			int cap = 0;
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("select capacity from Service1 where serviceId=:id");
			query.setParameter("id", serviceid);
			List<Integer> lst = query.list();
			cap = lst.get(0);
			return cap;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return 0;
	}

}
