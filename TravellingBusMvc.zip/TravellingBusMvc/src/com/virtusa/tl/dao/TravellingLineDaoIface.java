package com.virtusa.tl.dao;

import java.sql.Date;
import java.util.List;
import com.virtusa.model.Service;
import com.virtusa.model.Card;

import  com.virtusa.model.*;


public interface TravellingLineDaoIface {
	int adminLogin(String name,String password);
	
	String addAdmin(String name,String password,String conpwd);
	
	Service[] findBuses(String from, String to, String dt);
	
	int[] getAllSeat(String serviceid,String sno);
	
	 int getFare(String servid); 
	 
	 String insertCard(Card c);
	 
	 String insertPayment(String payid,String bookingid,String creditCardNo,int totalFare );
	 
	 String passengerDetails();
	 
	 boolean check(Card tl);
	 
	 String paymentIdGenrate();
	 
	 String pnrGenrate() ;
	 
	 String passengerIdGenrate();
	 
	 String genrateServiceId();
	 
	 String genrateBookingId();
	 
	 String insertInBookMap(String bookingId,String[] pname,String[] page,String[] seatNo);
	 
	 String insertBooking(String bookingId,String pnrno, Date journeyDate,String serviceId,String passengerId,int noOfSeats);
	 
	 String ticketDetail(String pnrNo,String[] pname,String[] page,String[] seatNo,Passenger md,String psngId);
	 
	 String cancelTicket(String pnrNo) ;
	 
	 Service detail(String serviceid);
	 
	 RetrievalDao pnrDetails(String pnrNo);
	 
	 String returnAmount(String pnrNo) ;
	 
	 boolean checkProof(String idtype);
	 
	 List<Service> displaySchedules();
	 
	 List<Service> modifyService(String serviceid);
	 
	 boolean checkPNR(String pnrno);
	 
	 String sendMessage(ContactUs cus);
	 
	 List<ContactUs> getAllMsg();
	 
	 int generatefeedbackId();
	 
	 int addFeedback(Feedback fb) ;
	 
	 List<Feedback> displayFeedback();
	 
	 int addService(Service s);
	 
	 int generateadminid();
	
	 int updateModifyService(Service s);
	
}
