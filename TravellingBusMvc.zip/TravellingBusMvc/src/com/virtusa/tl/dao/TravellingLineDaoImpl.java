package com.virtusa.tl.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import com.virtusa.model.ContactUs;
import com.virtusa.model.Feedback;
import com.virtusa.model.Passenger;
import com.virtusa.model.RetrievalDao;
import com.virtusa.model.Service;
import com.virtusa.model.Card;
import com.virtusa.util.DaoConnection;

import org.apache.log4j.Logger;

public class TravellingLineDaoImpl implements TravellingLineDaoIface {

	static Logger logger = Logger.getLogger(TravellingLineDaoImpl.class);
	PreparedStatement stm = null;

	Connection con;
	ResultSet rs = null;
	static StringBuilder strb = new StringBuilder();

	public TravellingLineDaoImpl() {
		con = DaoConnection.getConnection();
	}

	@Override
	public int generateadminid() {

		String cmd = "select case when max(admin_id) is null then 1 else max(admin_id)+1 end admin_id from administrator";
		try {

			stm = con.prepareStatement(cmd);
			rs = stm.executeQuery();
			rs.next();
			return rs.getInt("admin_id");
		} catch (SQLException e) {
			e.getMessage();
		} finally {
			try {
				if (stm != null) {
					stm.close();
				}
				if (rs != null) {
					rs.close();

				}

			} catch (SQLException e) {

				logger.error(e.getMessage());
			}
		}

		return 0;
	}

	@Override
	public int adminLogin(String name, String password) {

		CallableStatement stm = null;
		int n = 0;
		try {
			stm = con.prepareCall("{call prcadminlogin(?,?,?)}");
			stm.setString(1, name);
			stm.setString(2, password);
			stm.registerOutParameter(3, Types.INTEGER);
			stm.execute();
			n = stm.getInt(3);

		} catch (SQLException e) {
			logger.error(e.getMessage());
		} finally {
			try {
				if (stm != null) {
					stm.close();
				}
			} catch (SQLException e) {

				logger.error(e.getMessage());
			}
		}

		return n;
	}

	@Override
	public String addAdmin(String name, String password, String conpwd) {
		String s = null;
		int x = 0;
		int n = 0;
		try {
			if (password.equals(conpwd)) {
				String cmd = "insert into administrator(admin_id,admin_name,password) values(?,?,?)";
				stm = con.prepareStatement(cmd);
				n = new TravellingLineDaoImpl().generateadminid();
				stm.setInt(1, n);
				stm.setString(2, name);
				stm.setString(3, password);
				x = stm.executeUpdate();
			}
			if (x > 0) {
				s = "added success";
			} else {
				s = "not added";
			}
		} catch (SQLException e) {

			logger.error(e.getMessage());
		}
		return s;

	}

	@Override
	public Service[] findBuses(String from, String to, String dt) {
		String cmd;
		String cmdCount = "select count(*) cnt from service where sr_from=? and sr_to=? and active='yes'";
		Service[] arr = null;
		int cnt1 = 0;
		try {
			cmd = "select * from service where sr_from=? and sr_to=? and active='yes' ";
			stm = con.prepareStatement(cmdCount);
			stm.setString(1, from);
			stm.setString(2, to);
			rs = stm.executeQuery();
			rs.next();
			cnt1 = rs.getInt("cnt");
			arr = new Service[cnt1];
			Service serv = null;
			stm = con.prepareStatement(cmd);
			stm.setString(1, from);
			stm.setString(2, to);
			ResultSet rs1 = stm.executeQuery();
			int i = 0;
			while (rs1.next()) {
				serv = new Service();
				serv.setServiceId(rs1.getString("service_Id"));
				serv.setTypeId(rs1.getString("type_Id"));
				serv.setDepartureTime(rs1.getString("departure_Time"));
				serv.setJourneyTime(rs1.getString("journey_Time"));
				serv.setFare(rs1.getInt("fare"));
				serv.setServiceNo(rs1.getString("service_No"));
				serv.setCapacity(rs1.getInt("capacity"));
				arr[i] = serv;
				i++;
			}
		} catch (SQLException e1) {
			logger.error(e1.getMessage());
		}

		return arr;
	}

	public int getSeatCapacity(String serviceid) {
		int cap = 0;
		String s = serviceid;
		String cmd = "select capacity from service where service_id=?";
		try {

			stm = con.prepareStatement(cmd);
			stm.setString(1, s);
			rs = stm.executeQuery();
			rs.next();
			cap = rs.getInt("capacity");
		} catch (SQLException e) {

			logger.error(e.getMessage());
		}

		return cap;
	}

	@Override
	public int[] getAllSeat(String serviceid, String sno) {
		String cmd1 = "select bm.seat_no from booking b inner join booking_map bm on bm.booking_id=b.booking_id where service_id=?";
		int x = 0;
		TravellingLineDaoImpl travel = new TravellingLineDaoImpl();
		int[] bs1 = new int[travel.getSeatCapacity(serviceid) + 1];
		try {
			PreparedStatement stm1 = con.prepareStatement(cmd1);
			stm1.setString(1, sno);
			rs = stm1.executeQuery();
			while (rs.next()) {
				x = rs.getInt("seat_no");
			}
			for (int i = 0; i < bs1.length; i++) {
				bs1[i] = 0;
			}
			while (rs.next()) {
				bs1[x] = rs.getInt("seat_no");
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return bs1;
	}

	@Override
	public int getFare(String servid) {

		String cmd = "select fare from service where service_id=?";
		int fare = 0;
		try {
			stm = con.prepareStatement(cmd);
			stm.setString(1, servid);
			rs = stm.executeQuery();
			rs.next();
			fare = rs.getInt("fare");
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return fare;
	}

	@Override
	public String insertCard(Card c) {

		String cmd = "insert into Creditcard ( CARD_NO, HOLDER_NAME, CVVNO,EXPIRY_DATE) values(?,?,?,?)";
		try {
			stm = con.prepareStatement(cmd);
			if (c.getCardNo() != null && c.getCardHn() != null && c.getCvvNo() != 0 && c.getExpDate() != null) {
				stm.setString(1, c.getCardNo());
				stm.setString(2, c.getCardHn());
				stm.setInt(3, c.getCvvNo());
				stm.setString(4, c.getExpDate());
				stm.executeUpdate();
				return "Inserted";
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return "not inserted";
	}

	@Override
	public String insertPayment(String payid, String bookingid, String creditCardNo, int totalFare) {

		String cmd2 = "insert into payment values(?,?,?,?)";
		try {
			stm = con.prepareStatement(cmd2);
			stm.setString(1, payid);
			stm.setString(2, bookingid);
			stm.setString(3, creditCardNo);
			stm.setInt(4, totalFare);
			stm.executeUpdate();
			return "inserted payment";
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return "not inserted paymnet";
	}

	@Override
	public String passengerDetails() {

		String cmd = "insert into TravelDetails (FULLNAME,SR_from,SR_TO,DateOfJourney,DepartureDate ) values (?,?,?,?,?)";
		try {
			stm = con.prepareStatement(cmd);
			rs = stm.executeQuery();
			while (rs.next()) {
				stm.setString(1, "FULLNAME");
				stm.setString(2, "SR_from");
				stm.setString(3, "SR_TO");
				stm.setString(4, "DateOfjourney");
				stm.setString(5, "Departure_date");
				return "details Inserted successfully";
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return null;
	}

	@Override
	public boolean check(Card tl) {
		if (tl.getCardNo().isEmpty()) {
			strb.append("Cardno can not be null");
		}
		if (tl.getCardNo().length() == 16) {
			strb.append("Cardno should be alphabetic");
		}
		if (tl.getCardHn().isEmpty()) {
			strb.append("name can not be null");
		}
		if (tl.getCardHn().matches("[a-zA-Z*$]")) {
			strb.append("name should be alphabetic");
		}

		if (tl.getCvvNo() == 3) {
			strb.append("cvv should not be greater than 3");
		}
		if (tl.getExpDate().isEmpty()) {
			strb.append("Expdate can not be null");
		}
		return false;
	}

	@Override
	public String paymentIdGenrate() {

		String cmd = "select " + "	Case when max(PAYMENT_ID) is null THEN 'PAY001' "
				+ "		 when max(PAYMENT_ID) is not null THEN  "
				+ "			Case When To_Number(substr(max(PAYMENT_ID),4))+1<10 THEN "
				+ "				concat('PAY00',TO_Char(to_number(substr(max(PAYMENT_ID),4))+1)) "
				+ "				WHEN To_Number(substr(max(PAYMENT_ID),4))+1>=10 AND To_Number(substr(max(PAYMENT_ID),4))+1<100 THEN "
				+ "				concat('PAY00',TO_Char(to_number(substr(max(PAYMENT_ID),4))+1)) "
				+ "				WHEN To_Number(substr(max(PAYMENT_ID),4))+1>100 THEN "
				+ "				concat('PAY',TO_Char(to_number(substr(max(PAYMENT_ID),4))+1)) "
				+ "	end end payid from payment";
		try {
			stm = con.prepareStatement(cmd);
			ResultSet rs = stm.executeQuery();
			rs.next();
			return rs.getString(1);
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return null;
	}

	@Override
	public String pnrGenrate() {

		String cmd = "select " + "	Case when max(pnr_no) is null THEN 'PNR001' "
				+ "		 when max(pnr_no) is not null THEN  "
				+ "			Case When To_Number(substr(max(pnr_no),4))+1<10 THEN "
				+ "				concat('PNR00',TO_Char(to_number(substr(max(pnr_no),4))+1)) "
				+ "				WHEN To_Number(substr(max(pnr_no),4))+1>=10 AND To_Number(substr(max(pnr_no),4))+1<100 THEN "
				+ "				concat('PNR00',TO_Char(to_number(substr(max(pnr_no),4))+1)) "
				+ "				WHEN To_Number(substr(max(pnr_no),4))+1>100 THEN "
				+ "				concat('s',TO_Char(to_number(substr(max(pnr_no),4))+1)) "
				+ "	end end pnr_no from booking";
		try {
			stm = con.prepareStatement(cmd);
			rs = stm.executeQuery();
			rs.next();
			return rs.getString("pnr_no");
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return null;
	}

	@Override
	public String passengerIdGenrate() {

		String cmd = "select" + "	Case when max(passenger_id) is null THEN 'P001'"
				+ "		 when max(passenger_id) is not null THEN "
				+ "			Case When To_Number(substr(max(passenger_id),2))+1<10 THEN"
				+ "				concat('P00',TO_Char(to_number(substr(max(passenger_id),2))+1))"
				+ "				WHEN To_Number(substr(max(passenger_id),2))+1>=10 AND To_Number(substr(max(passenger_id),2))+1<100 THEN"
				+ "				concat('P0',TO_Char(to_number(substr(max(passenger_id),2))+1))"
				+ "				WHEN To_Number(substr(max(passenger_id),2))+1>100 THEN"
				+ "				concat('P',TO_Char(to_number(substr(max(passenger_id),2))+1))"
				+ "	end end passenger_id from passenger";
		try {
			stm = con.prepareStatement(cmd);
			rs = stm.executeQuery();
			rs.next();
			return rs.getString("passenger_id");
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return null;
	}

	@Override
	public String genrateServiceId() {

		String cmd = "select \r\n" + "	Case when max(service_id) is null THEN 's001'\r\n"
				+ "		 when max(service_id) is not null THEN \r\n"
				+ "			Case When To_Number(substr(max(service_id),2))+1<10 THEN\r\n"
				+ "				concat('s00',TO_Char(to_number(substr(max(service_id),2))+1))\r\n"
				+ "				WHEN To_Number(substr(max(service_id),2))+1>=10 AND To_Number(substr(max(service_id),2))+1<100 THEN\r\n"
				+ "				concat('s0',TO_Char(to_number(substr(max(service_id),2))+1))\r\n"
				+ "				WHEN To_Number(substr(max(service_id),2))+1>100 THEN\r\n"
				+ "				concat('s',TO_Char(to_number(substr(max(service_id),2))+1))\r\n"
				+ "	end end service_id from service";
		try {
			stm = con.prepareStatement(cmd);
			rs = stm.executeQuery();
			rs.next();
			return rs.getString("service_id");
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return null;
	}

	@Override
	public String genrateBookingId() {

		String cmd = "select \r\n" + "	Case when max(booking_id) is null THEN 'BN01'\r\n"
				+ "		 when max(booking_id) is not null THEN \r\n"
				+ "			Case When To_Number(substr(max(booking_id),3))+1<10 THEN\r\n"
				+ "				concat('BN0',TO_Char(to_number(substr(max(booking_id),3))+1))\r\n"
				+ "				ELSE\r\n"
				+ "				concat('BN',TO_Char(to_number(substr(max(booking_id),3))+1))\r\n"
				+ "	end end booking_id from booking";
		try {
			stm = con.prepareStatement(cmd);
			rs = stm.executeQuery();
			rs.next();
			return rs.getString("booking_id");
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return null;
	}

	@Override
	public String insertInBookMap(String bookingId, String[] pname, String[] page, String[] seatNo) {

		String cmd = "insert into booking_map(BOOKING_ID,seat_no,pname,age) values(?,?,?,?)";
		try {
			stm = con.prepareStatement(cmd);
			for (int i = 0; i < pname.length; i++) {
				stm.setString(1, bookingId);
				stm.setString(2, seatNo[i]);
				stm.setString(3, pname[i]);
				stm.setString(4, page[i]);
				stm.executeUpdate();
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return "inserted book map";
	}

	@Override
	public String insertBooking(String bookingId, String pnrno, Date journeyDate, String serviceId, String passengerId,
			int noOfSeats) {

		String cmd = "insert into booking(BOOKING_ID,PNR_NO,JOURNEY_DATE,SERVICE_ID,PASSENGER_ID,NO_OF_SEATS) values(?,?,?,?,?,?)";
		try {
			stm = con.prepareStatement(cmd);
			stm.setString(1, bookingId);
			stm.setString(2, pnrno);
			stm.setDate(3, journeyDate);
			stm.setString(4, serviceId);
			stm.setString(5, passengerId);
			stm.setInt(6, noOfSeats);
			stm.executeUpdate();
			return "booking inserted";
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return "booking not inserted";
	}

	@Override
	public String ticketDetail(String pnrNo, String[] pname, String[] page, String[] seatNo, Passenger md,
			String psngId) {

		try {
			String cmdInsertIdentity = "Insert into identity (PROOF_ID,PROOF_NAME) values(?,?) ";
			PreparedStatement stm2 = con.prepareStatement(cmdInsertIdentity);
			stm2.setString(1, md.getPno());
			stm2.setString(2, md.getProofType());
			stm2.executeUpdate();

			String cmd1 = "Insert into passenger (pnrno,FullName,ID_TYPE,ID_NO,MAIL_ID,MOBILE_NO,passenger_id) values(?,?,?,?,?,?,?)";
			stm = con.prepareStatement(cmd1);
			stm.setString(1, pnrNo);
			stm.setString(2, md.getName());
			stm.setString(3, md.getProofType());
			stm.setString(4, md.getPno());
			stm.setString(5, md.getEmail());
			stm.setLong(6, md.getMobNo());
			stm.setString(7, psngId);
			stm.executeUpdate();
			logger.info("passenger inserted");
			String cmd = "insert into PassengerDetail values(?,?)";
			stm = con.prepareStatement(cmd);

			for (int i = 0; i < pname.length; i++) {
				stm.setString(1, pnrNo);
				stm.setString(2, pname[i] + " " + page[i] + " " + seatNo[i]);
				stm.executeUpdate();
			}

			return "inserted passenger details";
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return "not inserted passenger";

	}

	@Override
	public String cancelTicket(String pnrNo) {

		String cmd = "select booking_id,passenger_id from booking where pnr_no=?";
		String findcmd = "select ID_NO from passenger where pnrno=?";
		String dcmd1 = "delete from passenger where passenger_id=?";
		String dcmd2 = "delete from booking_map where booking_id=?";
		String dcmd3 = "delete from payment where booking_id=?";
		String dcmd4 = "delete from booking where booking_id=?";
		String dcmd5 = "delete from identity where PROOF_ID=?";
		String pid = null;
		String bid = null;
		String idno = null;
		try {
			stm = con.prepareStatement(cmd);
			stm.setString(1, pnrNo);
			rs = stm.executeQuery();
			if (rs.next()) {
				bid = rs.getString(1);// got bookingid
				pid = rs.getString(2);// got passengerid
			}

			stm = con.prepareStatement(findcmd);
			stm.setString(1, pnrNo);
			ResultSet rs2 = stm.executeQuery();
			if (rs2.next()) {
				idno = rs2.getString(1);// got ID no
			}

			// ==========================================================
			stm = con.prepareStatement(dcmd3);
			stm.setString(1, bid);
			stm.executeUpdate();// delete for, payment

			stm = con.prepareStatement(dcmd2);
			stm.setString(1, bid);
			stm.executeUpdate();// delte from booking_map

			stm = con.prepareStatement(dcmd4);
			stm.setString(1, bid);
			stm.executeUpdate();// delete form booking

			stm = con.prepareStatement(dcmd1);
			stm.setString(1, pid);
			stm.executeUpdate();// delete data from paseneger

			stm = con.prepareStatement(dcmd5);
			stm.setString(1, idno);
			stm.executeUpdate();// delete data from idtype

			return "ticket cancelled";
		} catch (SQLException e) {
			logger.error(e.getMessage());

		}
		return "ticket not cancelled";
	}

	@Override
	public Service detail(String serviceid) {

		String cmd = "select service_id,type_id,DEPARTURE_TIME,JOURNEY_TIME,fare,service_no,capacity,sr_from,sr_to from service where service_id=?";
		Service serv = null;
		try {

			stm = con.prepareStatement(cmd);
			stm.setString(1, serviceid);
			rs = stm.executeQuery();
			while (rs.next()) {
				serv = new Service();
				serv.setServiceId(rs.getString(1));
				serv.setTypeId(rs.getString(2));
				serv.setDepartureTime(rs.getString(3));
				serv.setJourneyTime(rs.getString(4));
				serv.setFare(rs.getInt(5));
				serv.setServiceNo(rs.getString(6));
				serv.setCapacity(rs.getInt(7));
				serv.setSrFrom(rs.getString(8));
				serv.setSrTo(rs.getString(9));
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return serv;
	}

	@Override
	public RetrievalDao pnrDetails(String pnrNo) {

		String cmd3 = "select service_id,booking_id from booking where pnr_no= ?";
		String cmd4 = "select * from service where service_id= ?";
		String cmd5 = "select JOURNEY_DATE from booking where service_id=?";
		String cmd6 = "select SEAT_NO,PNAME from booking_map where booking_id=?";
		String cmd7 = "select FULLNAME,ID_TYPE from passenger where pnrno=?";
		RetrievalDao rdao = new RetrievalDao();
		try {

			stm = con.prepareStatement(cmd3);
			stm.setString(1, pnrNo);
			rs = stm.executeQuery();
			rs.next();
			String serviceid = rs.getString(1); // got service id
			String bookingId = rs.getString(2); // got Booking id

			stm = con.prepareStatement(cmd4);
			stm.setString(1, serviceid);
			ResultSet rs4 = stm.executeQuery();
			Service servs = new Service();
			while (rs4.next()) {
				servs.setSrFrom(rs4.getString(2));
				servs.setSrTo(rs4.getString(3));
				servs.setDepartureTime(rs4.getString(9));
				servs.setServiceNo(rs4.getString("SERVICE_NO"));
				servs.setFare(rs4.getInt(5));
				servs.setJourneyTime(rs4.getString(10));
			}
			rdao.setSer(servs);

			stm = con.prepareStatement(cmd5);
			stm.setString(1, serviceid);
			ResultSet rs5 = stm.executeQuery();
			rs5.next();
			rdao.setJourneydate(rs5.getDate(1));// got journey Date

			stm = con.prepareStatement(cmd6);
			stm.setString(1, bookingId);
			ResultSet rs6 = stm.executeQuery();
			List<String> pnames = new ArrayList<>();
			List<Integer> seats = new ArrayList<>();
			while (rs6.next()) {
				pnames.add(rs6.getString("PNAME"));
				seats.add(rs6.getInt("SEAT_NO"));
			}
			rdao.setPname(pnames);// got all names of db
			rdao.setSeatNo(seats);// got all seats from db

			stm = con.prepareStatement(cmd7);
			stm.setString(1, pnrNo);
			ResultSet rs7 = stm.executeQuery();

			if (rs7.next()) {
				rdao.setMasterName(rs7.getString(1));
				rdao.setMasterProofType(rs7.getString(2));
			} // got master detail and ip proof type

		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return rdao;
	}

	@Override
	public String returnAmount(String pnrNo) {

		String cmd1 = "select booking_id from booking where pnr_no= ?";
		String cmd2 = "select CREDIT_CARD_NO from payment where booking_id= ?";
		String cmd3 = "update creditcard set available_balance=(select total_fare-total_fare from payment where booking_id=?) where card_no=?";
		String cmd4 = "delete from payment where booking_id=?";
		try {
			stm = con.prepareStatement(cmd1);
			stm.setString(1, pnrNo);
			rs = stm.executeQuery();
			rs.next();
			String bookingId = rs.getString(1);// got booking id

			stm = con.prepareStatement(cmd2);
			stm.setString(1, bookingId);
			ResultSet rs4 = stm.executeQuery();
			rs4.next();
			String cardNo = rs4.getString(1);// got card no from payment

			stm = con.prepareStatement(cmd3);
			stm.setString(1, bookingId);
			stm.setString(2, cardNo);
			stm.executeUpdate();// updated available balance in creditcard

			stm = con.prepareStatement(cmd4);
			stm.setString(1, bookingId);
			stm.executeUpdate();// delete cardno from payment
			return "returened AMount";
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return "Not returened AMount";

	}

	@Override
	public boolean checkProof(String idtype) {

		String cmd = "select count(*) from identity where PROOF_ID= ?";
		try {
			stm = con.prepareStatement(cmd);
			stm.setString(1, idtype);
			rs = stm.executeQuery();
			rs.next();
			if (rs.getInt(1) > 0) {
				return true;
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return false;
	}

	@Override
	public List<Service> displaySchedules() {
		con = DaoConnection.getConnection();
		List<Service> scheduleslist = new ArrayList<>();
		try {
			String cmd = "select * from service order by service_id";
			stm = con.prepareStatement(cmd);
			rs = stm.executeQuery();
			while (rs.next()) {
				Service s = new Service();
				s.setServiceId(rs.getString("service_id"));
				s.setServiceNo(rs.getString("service_no"));
				s.setFare(rs.getInt("fare"));
				s.setSrFrom(rs.getString("sr_from"));
				s.setSrTo(rs.getString("sr_to"));
				s.setTypeId(rs.getString("type_id"));
				s.setDepartureTime(rs.getString("departure_time"));
				s.setJourneyTime(rs.getString("journey_time"));
				s.setCapacity(rs.getInt("capacity"));
				scheduleslist.add(s);
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return scheduleslist;
	}

	@Override
	public List<Service> modifyService(String serviceid) {
		con = DaoConnection.getConnection();
		List<Service> scheduleslist = new ArrayList<>();
		try {
			String cmd = "select * from service where service_id=?";
			stm = con.prepareStatement(cmd);
			stm.setString(1, serviceid);
			rs = stm.executeQuery();
			Service s = null;
			while (rs.next()) {
				s = new Service();
				s.setServiceId(rs.getString("service_id"));
				s.setServiceNo(rs.getString("service_no"));
				s.setFare(rs.getInt("fare"));
				s.setSrFrom(rs.getString("sr_from"));
				s.setSrTo(rs.getString("sr_to"));
				s.setTypeId(rs.getString("type_id"));
				s.setDepartureTime(rs.getString("departure_time"));
				s.setJourneyTime(rs.getString("journey_time"));
				s.setCapacity(rs.getInt("capacity"));
				scheduleslist.add(s);
			}

		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return scheduleslist;
	}

	@Override
	public boolean checkPNR(String pnrno) {

		String cmd = "select count(*) from booking where pnr_no= ?";
		try {
			stm = con.prepareStatement(cmd);
			stm.setString(1, pnrno);
			rs = stm.executeQuery();
			rs.next();
			if (rs.getInt(1) > 0) {
				return true;
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return false;
	}

	@Override
	public String sendMessage(ContactUs cus) {

		try {
			stm = con.prepareStatement("insert into contactus(fullname,email,phone,msg)  values(?,?,?,?)");
			stm.setString(1, cus.getname());
			stm.setString(2, cus.getEmail());
			stm.setString(3, cus.getPhone());
			stm.setString(4, cus.getMsg());
			stm.executeUpdate();
			return "Your Message Sent Succesfully!";
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return "Your Message is not Sent!";
	}

	@Override
	public List<ContactUs> getAllMsg() {
		List<ContactUs> allContacts = new ArrayList<>();
		ContactUs objcs = null;

		try {
			stm = con.prepareStatement("select * from contactus order by contact_date desc");
			rs = stm.executeQuery();
			while (rs.next()) {
				objcs = new ContactUs();
				objcs.setname(rs.getString(1));
				objcs.setEmail(rs.getString(2));
				objcs.setPhone(rs.getString(3));
				objcs.setMsg(rs.getString(4));
				objcs.setDateConatct(rs.getDate(5).toString());
				allContacts.add(objcs);
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}

		return allContacts;

	}

	@Override
	public int generatefeedbackId() {
		con = DaoConnection.getConnection();

		String cmd = "select case when max(feedback_id) is NULL then 1 else max(feedback_id)+1 end feedback_id from feedback";
		int fId = 0;

		try {
			stm = con.prepareStatement(cmd);
			rs = stm.executeQuery();
			rs.next();
			fId = rs.getInt("feedback_id");
			return fId;

		} catch (SQLException e) {
			logger.error(e.getMessage());
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				logger.error(e.getMessage());
			}
		}

		return 0;
	}

	@Override
	public int addFeedback(Feedback fb) {
		con = DaoConnection.getConnection();

		String cmd = "insert into feedback(feedback_id,customer_name,mail_id,comments)values(?,?,?,?)";
		try {
			int fid = new TravellingLineDaoImpl().generatefeedbackId();
			stm = con.prepareStatement(cmd);
			stm.setInt(1, fid);
			stm.setString(2, fb.getCustomerName());
			stm.setString(3, fb.getMailId());
			stm.setString(4, fb.getComments());
			return stm.executeUpdate();

		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return 0;

	}

	@Override
	public List<Feedback> displayFeedback() {
		con = DaoConnection.getConnection();
		List<Feedback> feedbackList = new ArrayList<>();
		try {
			String cmd = "select * from feedback order by date_of_given desc";
			stm = con.prepareStatement(cmd);
			rs = stm.executeQuery();

			while (rs.next()) {
				Feedback fb = new Feedback();
				fb.setCustomerName(rs.getString("customer_name"));
				fb.setMailId(rs.getString("mail_id"));
				fb.setComments(rs.getString("comments"));
				feedbackList.add(fb);
			}

		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return feedbackList;
	}

	@Override
	public int addService(Service s) {
		con = DaoConnection.getConnection();

		String rs = "yes";
		String cmd = "insert into service(service_id,sr_from,sr_to,type_id,fare,dist_kms,active,capacity,departure_time,journey_time,service_no) values(?,?,?,?,?,?,?,?,?,?,?)";
		try {
			int x = 0;
			stm = con.prepareStatement(cmd);
			stm.setString(1, new TravellingLineDaoImpl().genrateServiceId());
			stm.setString(2, s.getSrFrom());
			stm.setString(3, s.getSrTo());
			stm.setString(4, s.getTypeId());
			stm.setInt(5, s.getFare());
			stm.setInt(6, s.getDisKMS());
			stm.setString(7, rs);
			stm.setInt(8, s.getCapacity());
			stm.setString(9, s.getDepartureTime());
			stm.setString(10, s.getJourneyTime());
			stm.setString(11, s.getServiceNo());
			x = stm.executeUpdate();
			return x;
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return 0;
	}

	@Override
	public int updateModifyService(Service s) {
		int x = 0;
		String cmd = "update service set sr_from=?,sr_to=?,type_id=?,fare=?,dist_kms=?,capacity=?,active=?,departure_time=?,journey_time=? where service_id=?";
		try {
			stm = con.prepareStatement(cmd);
			stm.setString(1, s.getSrFrom());
			stm.setString(2, s.getSrTo());
			stm.setString(3, s.getTypeId());
			stm.setInt(4, s.getFare());
			stm.setInt(5, s.getDisKMS());
			stm.setInt(6, s.getCapacity());
			stm.setString(7, s.getActive());
			stm.setString(8, s.getDepartureTime());
			stm.setString(9, s.getJourneyTime());
			stm.setString(10, s.getServiceId());
			x = stm.executeUpdate();
			return x;
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return 0;
	}

}
