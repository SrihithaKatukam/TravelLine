package com.virtusa.model;

public class Service {
	private String serviceId;
	private String typeId;
	private String srFrom;
	private String srTo;
	private String journeyTime;
	private String departureTime;
	private int fare;
	private String active;
	private int capacity;
	private int disKMS;
	private String serviceNo;
	

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getTypeId() {
		return typeId;
	}

	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}

	public String getSrFrom() {
		return srFrom;
	}

	public void setSrFrom(String srFrom) {
		this.srFrom = srFrom;
	}

	public String getSrTo() {
		return srTo;
	}

	public void setSrTo(String srTo) {
		this.srTo = srTo;
	}

	public String getJourneyTime() {
		return journeyTime;
	}

	public void setJourneyTime(String journeyTime) {
		this.journeyTime = journeyTime;
	}

	public String getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}

	public int getFare() {
		return fare;
	}

	public void setFare(int fare) {
		this.fare = fare;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public int getDisKMS() {
		return disKMS;
	}

	public void setDisKMS(int disKMS) {
		this.disKMS = disKMS;
	}

	public String getServiceNo() {
		return serviceNo;
	}

	public void setServiceNo(String serviceNo) {
		this.serviceNo = serviceNo;
	}

}
