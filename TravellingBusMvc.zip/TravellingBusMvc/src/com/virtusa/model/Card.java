package com.virtusa.model;

public class Card {

	private String cardNo;
	private String cardHn;
	private int cvvNo;
	private String expDate;

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getCardHn() {
		return cardHn;
	}

	public void setCardHn(String cardHn) {
		this.cardHn = cardHn;
	}

	public int getCvvNo() {
		return cvvNo;
	}

	public void setCvvNo(int cvvNo) {
		this.cvvNo = cvvNo;
	}

	public String getExpDate() {
		return expDate;
	}

	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}	
	
}
