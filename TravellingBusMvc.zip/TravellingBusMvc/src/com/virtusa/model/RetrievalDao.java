package com.virtusa.model;

import java.sql.Date;
import java.util.List;
public class RetrievalDao {
	private Service ser;
	private Date journeydate;
	private List<String> pname;
	private List<Integer> seatNo;
	private String masterName;
	private String masterProofType;
	
	
	public String getMasterName() {
		return masterName;
	}
	public void setMasterName(String masterName) {
		this.masterName = masterName;
	}
	public String getMasterProofType() {
		return masterProofType;
	}
	public void setMasterProofType(String masterProofType) {
		this.masterProofType = masterProofType;
	}
	public List<String> getPname() {
		return pname;
	}
	public void setPname(List<String> pname) {
		this.pname = pname;
	}
	public List<Integer> getSeatNo() {
		return seatNo;
	}
	public void setSeatNo(List<Integer> seatNo) {
		this.seatNo = seatNo;
	}
	public Service getSer() {
		return ser;
	}
	public void setSer(Service ser) {
		this.ser = ser;
	}
	public Date getJourneydate() {
		return journeydate;
	}
	public void setJourneydate(Date journeydate) {
		this.journeydate = journeydate;
	}
}
