package com.virtusa.model;

import org.apache.log4j.Logger;

public class Feedback {
	private int feedbackId;
	private String customerName;
	private String mailId;
	private String comments;

	static Logger logger = Logger.getLogger(Feedback.class);

	public int getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public static Logger getLogger() {
		return logger;
	}

	public static void setLogger(Logger logger) {
		Feedback.logger = logger;
	}

	
}
