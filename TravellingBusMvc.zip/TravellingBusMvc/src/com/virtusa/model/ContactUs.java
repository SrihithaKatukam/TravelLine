package com.virtusa.model;

import org.apache.log4j.Logger;


public class ContactUs {
	private String name;
	private String email;
	private String phone;
	private String msg;
	private String dateConatct;

	static Logger logger = Logger.getLogger(ContactUs.class);

	public String getname() {
		return name;
	}

	public void setname(String name1) {
		name = name1;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getDateConatct() {
		return dateConatct;
	}

	public void setDateConatct(String dateConatct) {
		this.dateConatct = dateConatct;
	}
}
