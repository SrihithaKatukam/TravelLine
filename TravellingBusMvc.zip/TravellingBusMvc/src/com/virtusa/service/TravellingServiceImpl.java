package com.virtusa.service;

import java.sql.Date;
import java.util.List;

import com.virtusa.model.ContactUs;
import com.virtusa.model.Feedback;
import com.virtusa.model.Passenger;
import com.virtusa.model.RetrievalDao;
import com.virtusa.model.Service;
import com.virtusa.model.Card;
import com.virtusa.tl.dao.TravellingLineDaoIface;
import com.virtusa.tl.dao.TravellingLineDaoImpl;

public class TravellingServiceImpl implements TravellingServiceIface {

	
TravellingLineDaoIface travel; 	
	

	public TravellingServiceImpl() {
	 travel=new TravellingLineDaoImpl();
}


	@Override
	public int adminLogin(String name, String password) {
	
		return travel.adminLogin(name, password);
	}


	@Override
	public String addAdmin(String name, String password, String conpwd) {
		
		return travel.addAdmin(name, password, conpwd);
	}


	@Override
	public Service[] findBuses(String from, String to, String dt) {
		
		return travel.findBuses(from, to, dt);
	}


	@Override
	public int[] getAllSeat(String serviceid, String sno) {
		
		return travel.getAllSeat(serviceid, sno);
	}


	@Override
	public int getFare(String servid) {
		
		return travel.getFare(servid);
	}


	@Override
	public String insertCard(Card c) {
		
		return travel.insertCard(c);
	}


	@Override
	public String insertPayment(String payid, String bookingid, String creditCardNo, int totalFare) {

		return travel.insertPayment(payid, bookingid, creditCardNo, totalFare);
	}

	

	@Override
	public String passengerDetails() {

		return travel.passengerDetails();
	}


	@Override
	public boolean check(Card tl) {

		return travel.check(tl);
	}


	@Override
	public String paymentIdGenrate() {

		return travel.paymentIdGenrate();
	}


	@Override
	public String pnrGenrate() {

		return travel.pnrGenrate();
	}


	@Override
	public String passengerIdGenrate() {

		return travel.passengerIdGenrate();
	}


	@Override
	public String genrateServiceId() {

		return travel.genrateServiceId();
	}


	@Override
	public String genrateBookingId() {

		return travel.genrateBookingId();
	}


	@Override
	public String insertInBookMap(String bookingId, String[] pname, String[] page, String[] seatNo) {

		return travel.insertInBookMap(bookingId, pname, page, seatNo);
	}


	@Override
	public String insertBooking(String bookingId, String pnrno, Date journeyDate, String serviceId, String passengerId,
			int noOfSeats) {

		return travel.insertBooking(bookingId, pnrno, journeyDate, serviceId, passengerId, noOfSeats);
	}


	@Override
	public String ticketDetail(String pnrNo, String[] pname, String[] page, String[] seatNo, Passenger md,
			String psngId) {

		return travel.ticketDetail(pnrNo, pname, page, seatNo, md, psngId);
	}


	@Override
	public String cancelTicket(String pnrNo) {

		return travel.cancelTicket(pnrNo);
	}


	@Override
	public Service detail(String serviceid) {

		return travel.detail(serviceid);
	}


	@Override
	public RetrievalDao pnrDetails(String pnrNo) {

		return travel.pnrDetails(pnrNo);
	}


	@Override
	public String returnAmount(String pnrNo) {

		return travel.returnAmount(pnrNo);
	}


	@Override
	public boolean checkProof(String idtype) {

		return travel.checkProof(idtype);
	}


	@Override
	public List<Service> displaySchedules() {

		return travel.displaySchedules();
	}


	@Override
	public List<Service> modifyService(String serviceid) {

		return travel.modifyService(serviceid);
	}


	@Override
	public boolean checkPNR(String pnrno) {

		return travel.checkPNR(pnrno);
	}


	@Override
	public String sendMessage(ContactUs cus) {

		return travel.sendMessage(cus);
	}


	@Override
	public List<ContactUs> getAllMsg() {

		return travel.getAllMsg();
	}


	@Override
	public int generatefeedbackId() {

		return travel.generatefeedbackId();
	}


	@Override
	public int addFeedback(Feedback fb ) {

		return travel.addFeedback(fb);
	}


	@Override
	public List<Feedback> displayFeedback() {

		return travel.displayFeedback();
	}


	@Override
	public int addService(Service s ) {

		return travel.addService(s);
	}


	@Override
	public int generateAdminId() {

		return travel.generateadminid();
	}


	@Override
	public int updateModifyService(Service s) {
		
		return travel.updateModifyService(s);
	}


}
