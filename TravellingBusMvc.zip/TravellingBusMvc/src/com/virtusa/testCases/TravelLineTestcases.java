package com.virtusa.testCases;


import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.virtusa.model.Admin;
import com.virtusa.model.Booking;
import com.virtusa.model.BookingMap;
import com.virtusa.model.Card;
import com.virtusa.model.ContactUs;
import com.virtusa.model.Feedback;
import com.virtusa.model.Identity;
import com.virtusa.model.Passenger;
import com.virtusa.model.Payment;
import com.virtusa.model.RetrievalDao;
import com.virtusa.model.Service;
import com.virtusa.service.TravellingServiceIface;
import com.virtusa.service.TravellingServiceImpl;

class TravelLineTestcases {
	
	TravellingServiceIface si=new TravellingServiceImpl();

	@Test
	public void testServiceSetters() {
		Service s=new  Service();
		s.setServiceId("s001");
		s.getServiceId();
		s.setSrFrom("hyderabad");
		s.getSrFrom();
		s.setSrTo("delhi");
		s.getSrTo();
		s.setCapacity(28);
		s.getCapacity();
		s.setActive("yes");
		s.getActive();
		s.setDepartureTime("09-09-2019");
		s.getDepartureTime();
		s.setDisKMS(200);
		s.getDisKMS();
		s.setFare(200);
		s.getFare();
		s.setJourneyTime("3");
		s.getJourneyTime();
		s.setServiceNo("ts02au1234");
		s.getServiceNo();
		s.setTypeId("Semi-sleeper");
		s.getTypeId();
	}
	
	@Test
	public void testFeedbackSetters() {
		Feedback f=new Feedback();
		f.setFeedbackId(1);
		f.getFeedbackId();
		f.setCustomerName("srihitha");
		f.getCustomerName();
		f.setMailId("sri@gmail.com");
		f.getMailId();
		f.setComments("working good");
		f.getComments();
	}
	
	@Test
	 public void testAdminSetters() {
		Admin a=new Admin();
		a.setAdminId(1);
		a.getAdminId();
		a.setAdminName("admin");
		a.getAdminName();
		a.setPassword("pass123");
		a.getPassword();
	}
	
	@Test
	public void testCardSetters() {
		Card c=new Card();
		c.setCardNo("123456789101");
		c.getCardNo();
		c.setCardHn("xyz");
		c.getCardHn();
		c.setCvvNo(123);
		c.getCvvNo();
	}
	
	@Test
	public void testContactusSetters() {
		ContactUs cu=new ContactUs();
		cu.setDateConatct("09-09-2019");
		cu.getDateConatct();
		cu.setEmail("xyz@gmail.com");
		cu.getEmail();
		cu.setMsg("my ticket issue");
		cu.getMsg();
		cu.setname("xyz");
		cu.getname();
		cu.setPhone("9090909090");
		cu.getPhone();
	}
	
	@Test
	public void testMaterDaoSetters() {
		Passenger m=new Passenger("xyz@gmail.com", "xyz", 1234567890, "aadhar", "p0001");
		m.setEmail("abc@gmail.com");
		m.getEmail();
		m.setMobNo(1234567892);
		m.getMobNo();
		m.setName("srihita");
		m.getName();
		m.setPno("p0002");
		m.getPno();
		m.setProofType("pan");
		m.getProofType();
	}

	@Test
	public void testRetrievalDaoSetters() {
		RetrievalDao r=new RetrievalDao();
		r.setMasterName("abhishek");
		r.getMasterName();
		r.setMasterProofType("aadhar");
		r.getMasterProofType();
		List<String> pnames = new ArrayList<>();
		pnames.add("krishna");
		pnames.add("kanth");
		r.setPname(pnames);
		r.getPname();
		List<Integer> seats = new ArrayList<>();
		seats.add(12);
		seats.add(13);
		r.setSeatNo(seats);
	}
	
	@Test
	public void testPaymentSetters() {
		Payment p=new Payment();
		p.setBookingId("BN01");
		p.getBookingId();
		p.setCreditCardNo("123456789012");
		p.getCreditCardNo();
		p.setPaymentId("PAY001");
		p.getPaymentId();
		p.setTotalFare(500);
		p.getTotalFare();
		
	}
	@Test
	public void testBookingmapSetters() {
		BookingMap b=new BookingMap();
		b.setAge(21);
		b.getAge();
		b.setBookingId("BN01");
		b.getBookingId();
		b.setPname("krishna");
		b.getPname();
		b.setSeatNo(11);
		b.getSeatNo();
		
	}
	
	@Test
	public void testBookingSetters() {
		Booking b=new Booking();
		b.setBookingId("BN01");
		b.getBookingId();
		b.setNoOfSeats(3);
		b.getNoOfSeats();
		b.setPassengerId("P001");
		b.getPassengerId();
		b.setPnrNo("PNR01");
		b.getPnrNo();
		b.setServiceId("s001");
		b.getServiceId();
	}
   @Test
   public void testIdentitySetters() {
	   Identity i=new Identity();
	   i.setProofId("12345678");
	   i.getProofId();
	   i.setProofName("licence");
	   i.getProofName();  
   }
 
   @Test
   public void testGenAdminId() {
	   int id=si.generateAdminId();
	   assertEquals(20, id);
	   
   }
   
   
   @Test
   public void testAddFeedback() {
	   Feedback fb=new Feedback();
	   fb.setFeedbackId(si.generateAdminId());
	   fb.setCustomerName("krishna");
	   fb.setMailId("krishna@gmail.com");
	   fb.setComments("good ");
	   int result=si.addFeedback(fb);
	   assertEquals(1, result);
	   
   }
   
   @Test
   public void testFeedbackIdGen() {
	   int fid=si.generatefeedbackId();
	   assertEquals(2, fid);
   }
   
   
   @Test
   public void testAddAdmin() { 
	   String result=si.addAdmin("sri", "pass123", "pass123");
	   assertEquals("added success", result);
   }
   
   @Test
   public void testAdminIdGen() {
	   int adId=si.generateAdminId();
	   assertEquals(19, adId);
   }
   
   
   
   @Test
   public void testAddService() {
	   Service s=new Service();
	   s.setServiceId(si.genrateServiceId());
	   s.setSrFrom("hyderabad");
	   s.setSrFrom("delhi");
	   s.setActive("yes");
	   s.setCapacity(32);
	   s.setDepartureTime("12:30 PM");
	   s.setDisKMS(200);
	   s.setFare(200);
	   s.setJourneyTime("4");
	   s.setServiceNo("ts12au9255");
	   s.setTypeId("AC");
   }
   
   @Test
   public void testGenServiceId() {
	   String servId=si.genrateServiceId();
	   assertEquals("s008",servId);
   }
   
   @Test
   public void testDisplayFeedback() {
	   List<Feedback> flist = new ArrayList<>();
	   flist=si.displayFeedback();
	   int size=flist.size();
	   assertEquals(1,size);
   }
   
   @Test
   public void testDisplayService() {
	   List<Service> slist=new ArrayList<>();
	   slist=si.displaySchedules();
	   int size=slist.size();
	   assertEquals(7, size);
	
   }
   
  @Test
  public void testModifyService() {
	  Service s=new Service();
	  s.setActive("NO");
	  assertEquals(1, si.updateModifyService(s));
	  
  }
  
   @Test
   public void testGenBookingId() {
	   String bid=si.genrateBookingId();
	   assertEquals("BN01", bid);
   }
   
   @Test
   public void testGenPassengerId() {
	   String pid=si.passengerIdGenrate();
	   assertEquals("P001", pid);

   }
   
   @Test
   public void testGenPaymentId() {
	   String paymentid=si.paymentIdGenrate();
	   assertEquals("PAY001", paymentid);
   }
	@Test
	public void testDisplayFeedbackValues() {
		List<Feedback> flist=new ArrayList<Feedback>();
		flist=si.displayFeedback();
		String str=flist.get(1).getCustomerName();
	    	assertEquals("lakshmikant", str);
	}
	
	@Test
	public void displaySchedulesValues() {
		List<Service> slist=new ArrayList<Service>();
		slist=si.displaySchedules();
		String str=slist.get(1).getSrFrom();
	    	assertEquals("hyd", str);
		
	}
	 @Test
	  	public void testDisplaySchedulesCount() {
	      	List<Service> list=si.displaySchedules();
	      	int size=list.size();
	      	assertEquals(7, size);
	      	assertNotNull(si.displaySchedules());
	      }
	 @Test
	 public void testFindBuses() {
		 Service[] buses=si.findBuses("Delhi","Chennai","30-jul-2019");
		 for (int i = 0; i < buses.length; i++) {
		 String srno=buses[0].getServiceNo();
		 assertEquals("AP12GZ1615", srno);
		 }
	 }
	 
	 @Test
	 public void testCheckProofId() {
		 assertEquals(false, si.checkProof("154512"));
	 }
	 
	 @Test
	 public void testCheckProofIdNeg() {
		 assertEquals(false, si.checkProof("K091234Q"));
	 }
	 
	 @Test
	 public void testReturnAmount() {
		 assertEquals("Not returened AMount", si.returnAmount("PNR003"));
	 }
	 
	 @Test
	 public void testDetail() {
		 Service s1;
		 s1=si.detail("s002");
		 assertEquals("chennai", s1.getSrFrom());
	 }
	 
	 @Test
	 public void testpassengerIdGen() {
		 assertEquals("P002", si.passengerIdGenrate());
	 }
	 
	 @Test
	 public void testBookingIdGen() {
		 assertEquals("BN02", si.genrateBookingId());
	 }
	 
	 @Test
	 public void testPNRGenerate() {
		 assertEquals("PNR001", si.pnrGenrate());
	 }
	 
	
	public void testInsertBooking() {
			String BookingId = si.genrateBookingId();
			String pnrno = si.pnrGenrate();
			String psngId = si.passengerIdGenrate();
			java.util.Date dt=new java.util.Date();
			assertEquals("booking inserted",si.insertBooking(BookingId, pnrno,(java.sql.Date)dt,"s003",psngId,3));
		}
	  
	 @Test
		public void testTicketDetail() {
			String pnrid=si.pnrGenrate();
			String psngId = si.passengerIdGenrate();
			String[] pname= {"srihitha"};
			String[] age= {"21"};
			String[] sno= {"15"};
			Passenger md=new Passenger("@gmailcom", "krishna", 9090, "aadhar card",psngId);
			assertEquals("inserted passenger details", si.ticketDetail(pnrid, pname, age, sno,md, psngId));
		}
	 
	 
	 
		@Test
		public void testCancelTicket() {
			assertEquals("ticket cancelled",si.cancelTicket("PNR001"));
		}
	
	 @Test
	 public void testCheckPNR()
	 {
		 assertEquals(false,si.checkPNR("PNR008"));
	 }
	 @Test
	 public void testPNRDetail() {
		 RetrievalDao rd=new RetrievalDao();
		 rd=si.pnrDetails("PNR003");
		 assertEquals(null, rd.getMasterName());
	 }
	 
	 @Test
	 public void testCheckPNRNeg(){
		 assertEquals(false,si.checkPNR("PN013"));
	 }
	 
	
	 @Test
		void  testInsertBookMap() {
			String[] pname= {"srihitha"};
			String[] age= {"21"};
			String[] sno= {"12"};
			assertEquals("inserted book map",si.insertInBookMap("BN03",pname,age,sno));
		}
	 
	 @Test
	 public void testInsertPayment() {
		 String pid=si.paymentIdGenrate();
		 assertEquals("not inserted paymnet", si.insertPayment(pid, "BN03", "1212121212121212", 200));
	 }
	 
	 @Test
		public void testsendMsg() {
			ContactUs c=new ContactUs();
			c.setDateConatct("30-jul-2019");
			c.setEmail("aa@gmail.com");
			c.setMsg("service");
			c.setname("aa");
			c.setPhone("9911345612");
			assertEquals("Your Message Sent Succesfully!", si.sendMessage(c));
		}
   
	 
   
}
