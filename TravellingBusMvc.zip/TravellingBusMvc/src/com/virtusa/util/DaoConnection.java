package com.virtusa.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;
import org.apache.log4j.Logger;


public class DaoConnection {
	static Logger logger = Logger.getLogger(DaoConnection.class);

	public static Connection getConnection() {

		ResourceBundle boundle = ResourceBundle.getBundle("ResourceBundle");
		String path = boundle.getString("DB_DRIVER_CLASS");
		String url = boundle.getString("DB_URL");
		String user = boundle.getString("DB_USERNAME");
		String pass = boundle.getString("DB_PASSWORD");
		try {
			Class.forName(path);
			return DriverManager.getConnection(url, user, pass);

		} catch (ClassNotFoundException | SQLException e) {
			logger.error(e.getMessage());
		}
		return null;
	}

}
