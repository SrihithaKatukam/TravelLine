package com.virtusa.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.virtusa.model.Passenger;
import com.virtusa.service.TravellingServiceIface;
import com.virtusa.service.TravellingServiceImpl;
import com.virtusa.tl.dao.TravellingLineDaoImpl;

import org.apache.log4j.Logger;
public class PaymentCardInput extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(TravellingLineDaoImpl.class);
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
		HttpSession session = request.getSession();
		String[] pname = request.getParameterValues("Pname");
		String[] pAge = request.getParameterValues("age");
		String[] seat = request.getParameterValues("seatno");
		session.setAttribute("proofid", request.getAttribute("proofId"));

		Passenger md = new Passenger(request.getParameter("Email"), pname[0],
				Long.parseLong(request.getParameter("Phone")), request.getParameter("ProofId"),
				request.getParameter("Proofno"));

		session.setAttribute("MasterDetail", md);
		session.setAttribute("pname", pname);
		session.setAttribute("pAge", pAge);
		session.setAttribute("Seatno", seat);

		
		// for inserting credit card details first we have to get serviceId.

		String servid = (String) session.getAttribute("sno");
		TravellingServiceIface daoImpl = new TravellingServiceImpl();
		int fare = daoImpl.getFare(servid) * seat.length;
		session.setAttribute("totalfare", fare);

		if (fare > 0) {
			response.sendRedirect("PaymentCardInput.jsp");
		} else {
			response.sendRedirect("Passenger.jsp");
		}
	} catch (Exception e) {
		logger.error(e.getMessage());
	}

	}
}
