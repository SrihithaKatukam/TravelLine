package com.virtusa.controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.service.TravellingServiceIface;
import com.virtusa.service.TravellingServiceImpl;
import com.virtusa.tl.dao.TravellingLineDaoImpl;

import org.apache.log4j.Logger;
public class AdminLogin extends HttpServlet {
	
	private static final long serialVersionUID = -6411541445508067414L;
	static Logger logger = Logger.getLogger(TravellingLineDaoImpl.class);
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     try {
		String name=request.getParameter("nam");
      String password=request.getParameter("pwd");
      HttpSession httpSession=request.getSession();
     
      TravellingServiceIface travellingServiceIface=new TravellingServiceImpl();
      int result=travellingServiceIface.adminLogin(name, password);
      if(result>0){
    	  httpSession.setAttribute("name",name);
    	  RequestDispatcher requestDispatcher=request.getRequestDispatcher("AdminAddFile.jsp");
    	  requestDispatcher.forward(request, response);
      }
      else {
    
    	  request.setAttribute("message","invalid credentials");
    	  RequestDispatcher requestDispatcher=request.getRequestDispatcher("LoginAdminjsp.jsp");
    	  requestDispatcher.forward(request, response);
      }	
	}catch(Exception e) {
		logger.error(e.getMessage());
	}
		
	}

}
