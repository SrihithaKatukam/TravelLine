package com.virtusa.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.model.RetrievalDao;
import com.virtusa.model.Service;
import com.virtusa.service.TravellingServiceIface;
import com.virtusa.service.TravellingServiceImpl;
import com.virtusa.tl.dao.TravellingLineDaoImpl;
import org.apache.log4j.Logger;

public class PnrCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(TravellingLineDaoImpl.class);

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		try {
			HttpSession session = request.getSession();
			String path = null;
			String s1 = null;
			TravellingServiceIface daoImpl = new TravellingServiceImpl();
			if ((String) request.getParameter("pnrno") != null && (String) request.getParameter("IdNo") != null) {
				if (daoImpl.checkPNR((String) request.getParameter("pnrno"))
						&& daoImpl.checkProof((String) request.getParameter("IdNo"))) {
					RetrievalDao rdao = new TravellingLineDaoImpl().pnrDetails((String) request.getParameter("pnrno"));
					session.setAttribute("pnrnofordelete", (String) request.getParameter("pnrno"));
					Service sobj = rdao.getSer();
					String servno = sobj.getServiceNo();
					List<String> allpassNames = rdao.getPname();
					List<Integer> allpassSeats = rdao.getSeatNo();
					request.setAttribute("pnrno", request.getParameter("pnrno"));
					request.setAttribute("allpassNames", allpassNames);
					request.setAttribute("allpassSeats", allpassSeats);
					request.setAttribute("sobj", sobj);
					request.setAttribute("servno", servno);
					request.setAttribute("rdao", rdao);
					path = "retrivalOpen.jsp";

				} else {
					s1 = "Not correct pnr or id proof";
					request.setAttribute("msg", s1);
					path = "PNRcheck.jsp";

				}
			}
			RequestDispatcher requestDispatcher = request.getRequestDispatcher(path);
			requestDispatcher.forward(request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

	}
}
