package com.virtusa.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.virtusa.model.Passenger;
import com.virtusa.service.TravellingServiceIface;
import com.virtusa.service.TravellingServiceImpl;
import com.virtusa.tl.dao.TravellingLineDaoImpl;
import com.virtusa.model.Card;
import org.apache.log4j.Logger;

public class PaymentCardInsert extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(TravellingLineDaoImpl.class);
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
		String s1 = null;
		String s2 = null;
		String s3 = null;
		String s4 = null;

		HttpSession session = request.getSession();
		String cardno = request.getParameter("card_no");
		String cardhn = request.getParameter("card_hn");
		int cvvno = Integer.parseInt(request.getParameter("cvvno"));
		String expdate = request.getParameter("exp_date");
		if (cardno != null && cardhn != null && cvvno != 0 && expdate != null) {
			Card c = new Card();
			c.setCardNo(cardno);
			c.setCardHn(cardhn);
			c.setCvvNo(cvvno);
			c.setExpDate(expdate);

			// to call function
			TravellingServiceIface daoImpl = new TravellingServiceImpl();
			daoImpl.insertCard(c);
			String pnrno = daoImpl.pnrGenrate();
			String psngId = daoImpl.passengerIdGenrate();
			String bookingid = daoImpl.genrateBookingId();
			java.util.Date ud = (java.util.Date) session.getAttribute("date");
			java.sql.Date d = new java.sql.Date(ud.getTime());

			session.setAttribute("pnrno", pnrno);

			s1 = daoImpl.ticketDetail(pnrno, (String[]) session.getAttribute("pname"),
					(String[]) session.getAttribute("pAge"), (String[]) session.getAttribute("Seatno"),
					(Passenger) session.getAttribute("MasterDetail"), psngId);

			s2 = daoImpl.insertBooking(bookingid, pnrno, d, (String) session.getAttribute("sno"), psngId,
					Integer.parseInt(session.getAttribute("noofpsg").toString()));

			// insert into booking map table
			s3 = daoImpl.insertInBookMap(bookingid, (String[]) session.getAttribute("pname"),
					(String[]) session.getAttribute("pAge"), (String[]) session.getAttribute("Seatno"));

			s4 = daoImpl.insertPayment(daoImpl.paymentIdGenrate(), bookingid, cardno,
					(int) session.getAttribute("totalfare"));

		}
		if (s1.equals("inserted passenger details") && s2.equals("booking inserted") && s3.equals("inserted book map")
				&& s4.equals("inserted payment")) {
			response.sendRedirect("ShowDetail.jsp");
		}
	} catch (Exception e) {
		logger.error(e.getMessage());
	}
	}
}