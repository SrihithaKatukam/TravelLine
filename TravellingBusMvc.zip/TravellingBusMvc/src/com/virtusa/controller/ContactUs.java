package com.virtusa.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.virtusa.service.TravellingServiceIface;
import com.virtusa.service.TravellingServiceImpl;
import com.virtusa.tl.dao.TravellingLineDaoImpl;

import org.apache.log4j.Logger;
public class ContactUs extends HttpServlet {

	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(TravellingLineDaoImpl.class);
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		try {
			HttpSession sesssion = request.getSession();
            String s=null;
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			String phone = request.getParameter("phone");
			String msg = request.getParameter("message");

			if (name != null && email != null && phone != null && msg != null) {
				com.virtusa.model.ContactUs contactUs = new com.virtusa.model.ContactUs();
				contactUs.setname(name);
				contactUs.setEmail(email);
				contactUs.setPhone(phone);
				contactUs.setMsg(msg);
				sesssion.setAttribute("contact", contactUs);
				TravellingServiceIface daoImpl = new TravellingServiceImpl();
				s = daoImpl.sendMessage(contactUs);
				if (s != null) {
					request.setAttribute("success", s);
					request.setAttribute("name", name);
					request.setAttribute("email", email);
					request.setAttribute("phone", phone);
					request.setAttribute("msg", msg);
					RequestDispatcher requestDispatcher=request.getRequestDispatcher("ContactUs.jsp");
					requestDispatcher.forward(request, response);
				}

				else
					response.sendRedirect("ContactUs.jsp");

			} else {
		    	 RequestDispatcher rd=request.getRequestDispatcher("NoRecordUser.jsp");
			    	rd.forward(request, response);
		     }

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

}
