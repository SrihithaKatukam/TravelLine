package com.virtusa.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.service.TravellingServiceIface;
import com.virtusa.service.TravellingServiceImpl;
import com.virtusa.tl.dao.TravellingLineDaoImpl;

import org.apache.log4j.Logger;

public class CancelTicket extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(TravellingLineDaoImpl.class);

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			
			String s3 = null;
			HttpSession session = request.getSession();
			TravellingServiceIface s = new TravellingServiceImpl();
			String s1 = s.returnAmount((String) session.getAttribute("pnrnofordelete"));
			String s2 = s.cancelTicket((String) session.getAttribute("pnrnofordelete"));
			if (s1.equals("returened AMount") && s2.equals("ticket cancelled")) {
				 s3 = "Your Ticket Has Been Cancelled Successfully";
				request.setAttribute("cancel", s3);
				RequestDispatcher rd = request.getRequestDispatcher("cancelTicket.jsp");
				rd.forward(request, response);
			}
			else {
				RequestDispatcher rd = request.getRequestDispatcher("retrivalOpen.jsp");
				rd.forward(request, response);
			}
			
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
}
