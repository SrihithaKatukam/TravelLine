package com.virtusa.controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.virtusa.model.ContactUs;
import com.virtusa.service.TravellingServiceIface;
import com.virtusa.service.TravellingServiceImpl;
import com.virtusa.tl.dao.TravellingLineDaoImpl;

import org.apache.log4j.Logger;

public class ContactAdminView extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(TravellingLineDaoImpl.class);
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
		HttpSession session = request.getSession();
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");// HTTP 1.1
		response.setHeader("Pragma", "no-cache");
		String svar = (String) session.getAttribute("name");
		if (svar == null) {
			RequestDispatcher rd = request.getRequestDispatcher("AllContactusAdminView.jsp");
			rd.forward(request, response);
		}
		TravellingServiceIface daoImpl = new TravellingServiceImpl();
		List<ContactUs> allmsg = daoImpl.getAllMsg();
		if (!allmsg.isEmpty()) {
			
			request.setAttribute("contactlist", allmsg);
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("AllContactusAdminView.jsp");
			requestDispatcher.forward(request, response);
		} else {
			RequestDispatcher rd = request.getRequestDispatcher("NoRecordAdmin.jsp");
			rd.forward(request, response);
		}
	} catch (Exception e) {
		logger.error(e.getMessage());
	}
	}
}
