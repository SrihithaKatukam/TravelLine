package com.virtusa.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.model.Feedback;
import com.virtusa.service.TravellingServiceIface;
import com.virtusa.service.TravellingServiceImpl;
import com.virtusa.tl.dao.TravellingLineDaoImpl;

import org.apache.log4j.Logger;

public class AddFeedbackController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(TravellingLineDaoImpl.class);
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
		TravellingServiceIface ts = new TravellingServiceImpl();
		com.virtusa.model.Feedback f = new Feedback();
		f.setFeedbackId(ts.generatefeedbackId());
		f.setCustomerName(request.getParameter("customerName"));
		f.setMailId(request.getParameter("mailId"));
		f.setComments(request.getParameter("comments"));
		int x = ts.addFeedback(f);
		if (x > 0) {
			RequestDispatcher rd = request.getRequestDispatcher("FeedbackAdded.jsp");
			rd.forward(request, response);
		}

	}catch(Exception e) {
		logger.error(e.getMessage());
	}
	}
}
