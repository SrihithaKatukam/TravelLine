package com.virtusa.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.virtusa.model.Service;
import com.virtusa.service.TravellingServiceIface;
import com.virtusa.service.TravellingServiceImpl;
import com.virtusa.tl.dao.TravellingLineDaoImpl;

import org.apache.log4j.Logger;

public class SelectService extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(TravellingLineDaoImpl.class);

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Service[] arr=null;
		try {
			String from = request.getParameter("from");
			String to = request.getParameter("to");
			String dt = request.getParameter("doj");
			int p = Integer.parseInt(request.getParameter("no_passenger"));
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			Date dcheck = null;
			dcheck = sdf.parse(dt);
			HttpSession session = request.getSession();
			session.setAttribute("fromplace", from);
			session.setAttribute("toplace", to);
			session.setAttribute("noofpsg", p);
			session.setAttribute("date", dcheck);
			TravellingServiceIface daoImpl = new TravellingServiceImpl();
			arr = daoImpl.findBuses(from, to, dt);
			if(arr.length > 0) {
				response.sendRedirect("SelectService.jsp");
			} else {
				response.sendRedirect("SelectService.jsp");
				
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

}
