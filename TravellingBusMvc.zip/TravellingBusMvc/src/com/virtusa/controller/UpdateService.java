package com.virtusa.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.virtusa.model.Service;
import com.virtusa.service.TravellingServiceIface;
import com.virtusa.service.TravellingServiceImpl;
import com.virtusa.tl.dao.TravellingLineDaoImpl;

import org.apache.log4j.Logger;
public class UpdateService extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(TravellingLineDaoImpl.class);
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
		String serviceid = request.getParameter("serviceId");
		String from = request.getParameter("srFrom");
		String to = request.getParameter("srTo");
		String bustype = request.getParameter("typeId");
		int fare = (Integer.parseInt(request.getParameter("fare")));
		int distance = (Integer.parseInt(request.getParameter("disKMS")));
		int capacity = (Integer.parseInt(request.getParameter("capacity")));
		String active = request.getParameter("active");
		String journeytime = request.getParameter("journeyTime");
		String departtime = request.getParameter("departureTime");
		String serviceno = request.getParameter("serviceNo");
		Service s = new Service();
		s.setServiceId(serviceid);
		s.setSrFrom(from);
		s.setSrTo(to);
		s.setActive(active);
		s.setCapacity(capacity);
		s.setDepartureTime(departtime);
		s.setJourneyTime(journeytime);
		s.setDisKMS(distance);
		s.setFare(fare);
		s.setTypeId(bustype);
		s.setServiceNo(serviceno);
		TravellingServiceIface serviceIface = new TravellingServiceImpl();
		int x = serviceIface.updateModifyService(s);
		if (x > 0) {
			RequestDispatcher rd = request.getRequestDispatcher("ServiceModified.jsp");
			rd.forward(request, response);
		}
	} catch (Exception e) {
		logger.error(e.getMessage());
	}
	}

}
