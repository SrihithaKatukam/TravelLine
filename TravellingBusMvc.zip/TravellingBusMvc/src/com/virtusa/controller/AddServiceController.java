package com.virtusa.controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.virtusa.model.Service;
import com.virtusa.service.TravellingServiceIface;
import com.virtusa.service.TravellingServiceImpl;
import com.virtusa.tl.dao.TravellingLineDaoImpl;

import org.apache.log4j.Logger;
public class AddServiceController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	static Logger logger = Logger.getLogger(TravellingLineDaoImpl.class);
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
         try {
		TravellingServiceIface ts = new TravellingServiceImpl();
		Service service = new Service();
		service.setServiceId(ts.genrateServiceId());
		service.setSrFrom(request.getParameter("srFrom"));
		service.setSrTo(request.getParameter("srTo"));
		service.setTypeId(request.getParameter("typeId"));
		service.setFare(Integer.parseInt(request.getParameter("fare")));
		service.setDisKMS(Integer.parseInt(request.getParameter("disKMS")));
		service.setCapacity(Integer.parseInt(request.getParameter("capacity")));
		service.setDepartureTime(request.getParameter("departureTime"));
		service.setJourneyTime(request.getParameter("journeyTime"));
		service.setServiceNo(request.getParameter("serviceNo"));
		String rs = "yes";
		service.setActive(rs);
		int x = ts.addService(service);
		if (x > 0) {
			RequestDispatcher rd = request.getRequestDispatcher("ServiceAdded.jsp");
			rd.forward(request, response);

		} else {
			RequestDispatcher rd = request.getRequestDispatcher("AddService.jsp");
			rd.include(request, response);
		}

	}catch(Exception e) {
		logger.error(e.getMessage());
	}
	}
}
