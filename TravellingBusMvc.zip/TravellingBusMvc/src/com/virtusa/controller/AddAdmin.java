package com.virtusa.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.virtusa.service.TravellingServiceIface;
import com.virtusa.service.TravellingServiceImpl;
import com.virtusa.tl.dao.TravellingLineDaoImpl;
import org.apache.log4j.Logger;
public class AddAdmin extends HttpServlet {

	private static final long serialVersionUID = -1236469281246860028L;
	static Logger logger = Logger.getLogger(TravellingLineDaoImpl.class);
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
		String msg = null;
		String name = request.getParameter("name");
		String password = request.getParameter("pas");
		String conpassword = request.getParameter("conpas");
		TravellingServiceIface daoImpl = new TravellingServiceImpl();
		String result = daoImpl.addAdmin(name, password, conpassword);
		if (result.equals("added success")) {
			msg = "Added Succesfully";
			request.setAttribute("msge", msg);
			RequestDispatcher rd = request.getRequestDispatcher("AdminAddFile.jsp");
			rd.forward(request, response);

		} else {
			msg = "Invalid password";
			request.setAttribute("msge", msg);
			RequestDispatcher rd = request.getRequestDispatcher("AdminAddFile.jsp");
			rd.forward(request, response);
		}
	}catch(Exception e) {
		logger.error(e.getMessage());
	}
	}
}
