package com.virtusa.Dao;

import java.util.Date;
import java.util.List;

import com.virtusa.model.Admin;
import com.virtusa.model.BookingMap;
import com.virtusa.model.Card;
import com.virtusa.model.ContactUs;
import com.virtusa.model.Feedback;
import com.virtusa.model.Passenger;
import com.virtusa.model.RetrievalDao;
import com.virtusa.model.Service1;

public interface TravelLineDaoIface {
	int adminLogin(String name, String password);

	String addAdmin(Admin ad);

	List<Service1> findBuses(String from, String to, String active);

	int[] getAllSeat(String serviceid, String sno);

	int getFare(String servid);

	int getSeatCapacity(String serviceid);

	int insertCard(Card c);

	String paymentIdGenrate();

	String pnrGenrate();

	String passengerIdGenrate();

	String genrateServiceId();

	String genrateBookingId();

	String insertBooking(Passenger passenger, String pnrno, Date journeyDate, String serviceId, String passengerId,
			int noOfSeats, String bookingid, Card card, int fare, List<BookingMap> bookingMap);

	Passenger ticketDetail(String pnrNo, String[] pname, String[] page, String[] seatNo, Passenger md, String psngId,
			String proof, String proofid);

	String cancelTicket(String pnrNo);

	RetrievalDao pnrDetails(String pnrNo);

	String returnAmount(String pnrNo);

	boolean checkProof(String idtype);

	List<Service1> displaySchedules();

	List<Service1> modifyService(String serviceid);

	boolean checkPNR(String pnrno);

	String sendMessage(ContactUs cus);

	List<ContactUs> getAllMsg();

	int addFeedback(Feedback fb);

	List<Feedback> displayFeedback();

	int addService(Service1 s);

	int updateModifyService(Service1 s);
}
