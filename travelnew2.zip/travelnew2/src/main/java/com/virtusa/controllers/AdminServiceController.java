package com.virtusa.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import javax.websocket.server.PathParam;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.virtusa.model.Service1;
import com.virtusa.services.TravelLineServiceIface;

@Controller
public class AdminServiceController {

	static Logger logger = Logger.getLogger(PaymentDetailController.class);
	@Autowired
	TravelLineServiceIface adminServiceIface;

	@RequestMapping(value = "/addservice", method = RequestMethod.POST)
	public ModelAndView addService(@Valid @ModelAttribute("service") Service1 service, BindingResult result) {
		try {
			ModelAndView modelAndView = new ModelAndView();
			if (!result.hasErrors()) {

				modelAndView.setViewName("AddService");
				int x = adminServiceIface.addService(service);
				if (x != 0) {

					String message = "Service Added Successfully";
					modelAndView.addObject("msg", message);
					modelAndView.setViewName("AddService");
				} else {

					String message = "Service Not Added Successfully";
					modelAndView.addObject("msg", message);
					modelAndView.setViewName("AddService");
				}
			} else {

				modelAndView.setViewName("AddService");
			}
			return modelAndView;
		} catch (Exception e) {
			logger.error(e.getMessage());

		}
		return null;

	}

	@RequestMapping(value = "/toAddService")
	public String takemetoaddadmin(Model m) {
		m.addAttribute("service", new Service1());
		return "AddService";
	}
	
	@RequestMapping(value = "/toAddAdmin")
	public String takemetoaddadmin1() {
		
		return "AdminAddFile";
	}

	@RequestMapping(value = "/modifyservice", method = RequestMethod.GET)
	public ModelAndView modifyService1() {

		String s = "No services are available";
		ModelAndView modelAndView = new ModelAndView();
		List<Service1> l = adminServiceIface.displaySchedules();
		if (!l.isEmpty()) {
			modelAndView.addObject("servicelist", l);
			modelAndView.setViewName("ModifyList");

		} else {
			modelAndView.addObject("msg", s);
			modelAndView.setViewName("ModifyList");
		}
		return modelAndView;
	}

	@RequestMapping(value = "/onmodify", method = RequestMethod.GET)
	public ModelAndView updateService(@PathParam("serviceId") String serviceid) {
		try {

			ModelAndView modelAndView = new ModelAndView();
			List<Service1> list = adminServiceIface.modifyService(serviceid);
			String s = "No services are available";
			if (!list.isEmpty()) {
				System.out.println(list.get(0).toString());
				System.out.println(serviceid);
				modelAndView.addObject("temp", list.get(0));
				modelAndView.setViewName("ModifyService");

			} else {
				System.out.println("hi i");
				modelAndView.addObject("noservice", s);
				modelAndView.setViewName("ModifyList");
			}
			return modelAndView;
		} catch (Exception e) {
			logger.error(e.getMessage());

		}
		return null;
	}

	@RequestMapping(value = "/toupdateservice1", method = RequestMethod.GET)
	public String modifyService() {
		return "redirect:/modifyservice";
	}

	@RequestMapping(value = "/tomodify", method = RequestMethod.GET)
	public String modifyService2() {
		return "redirect:onmodifyclick";
	}

	@RequestMapping(value = "/updateservice", method = RequestMethod.POST)
	public ModelAndView updatemodifyService(Service1 service, HttpSession session) {
		try {
			ModelAndView modelAndView = new ModelAndView();
			int x = adminServiceIface.updateModifyService(service);
			String msg = "Service updated Successfully";
			if (x > 0) {
				modelAndView.addObject("msg", msg);
				modelAndView.addObject("modifyservice", service);
				modelAndView.setViewName("ModifyService");
			}
			return modelAndView;
		} catch (Exception e) {
			logger.error(e.getMessage());

		}
		return null;

	}

}
