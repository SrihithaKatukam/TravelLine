package com.virtusa.model.idgenerate;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.hibernate.HibernateException;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.id.IdentifierGenerator;

public class PaymentId implements IdentifierGenerator {
	public Serializable generate(SessionImplementor session, Object object) throws HibernateException {
		Connection connection = session.connection();
		try {
			Statement statement = connection.createStatement();

			ResultSet rs = statement.executeQuery("select count(paymentId) from payment_table");

			if (rs.next()) {
				String generatedId = null;
				System.out.println(rs.getInt(1));
				int id = rs.getInt(1) + 1;
				if (id < 10) {
					generatedId = "PAY0" + new Integer(id).toString();
				} else if (id > 9) {
					generatedId = "PAY" + new Integer(id).toString();
				} else if (id > 99) {
					generatedId = "PAY" + new Integer(id).toString();
				}
				System.out.println("Generated Id: " + generatedId);
				return generatedId;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}
