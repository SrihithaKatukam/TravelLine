package com.virtusa.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "contact_table2")
public class ContactUs {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int srno;

	@Column
	private String name;

	@Column(name = "mail_id")
	private String email;

	@Column
	private String phone;

	@Column(name = "message")
	private String msg;

	@Column
	@Temporal(TemporalType.DATE)
	private Date dateConatct;

	public int getSrno() {
		return srno;
	}

	public void setSrno(int srno) {
		this.srno = srno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDateConatct() {
		return dateConatct;
	}

	public void setDateConatct(Date dateConatct) {
		this.dateConatct = dateConatct;
	}

	public String getname() {
		return name;
	}

	public void setname(String name1) {
		name = name1;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}


}
